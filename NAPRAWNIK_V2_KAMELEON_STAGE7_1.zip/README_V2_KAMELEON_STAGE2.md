# NAPRAWNIK V2 — Kameleon / Stage 2

Ten pakiet jest kolejnym etapem nad fundamentem V2.

## Zrobione
- tryb `WARSZTAT` / `AMATOR`, zapisany w AsyncStorage
- ekran główny Kameleon z ciemnym tłem i gradientem fiolet → magenta → pomarańcz
- wybór wariantu kolorystycznego Kameleon / Fioletowy / Pomarańczowy
- kartoteka pojazdów jako centralny punkt pracy
- wybór profilu silnika z `ENGINE_PROFILES` przy tworzeniu pojazdu
- blokada duplikatu VIN
- wyświetlanie profilu silnika na karcie pojazdu
- zachowanie istniejącej diagnostyki krok po kroku, historii i elektryki
- ustawienia trybu, wyglądu, backupu i czyszczenia danych

## Walidacja
Przeprowadzono translację składniową przez TypeScript dla:
- `App.js`
- `DiagnosisCore.js`
- `NAPRAWNIK_ELEKTRYKA_BAZA_v1.js`

Wszystkie trzy pliki przeszły bez błędów parsera.

## Następny etap
1. pełne spięcie `vehicleId` z Notatnikiem / Czarną Skrzynką / przypomnieniami
2. test przed/po naprawie
3. zdjęcia przed/po
4. płyny i interwały serwisowe
5. dalsze dopracowanie Kameleon UI
6. test w Expo i dopiero potem APK

Uwaga: wybór motywu w tym etapie zmienia przede wszystkim elementy gradientowe i branding; pełne przełączenie wszystkich kolorów komponentów będzie osobnym etapem UI.
