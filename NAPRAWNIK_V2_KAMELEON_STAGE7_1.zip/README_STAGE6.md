# NAPRAWNIK V2 — Kameleon Stage 6 / Stabilizacja produkcyjna

Stage 6 nie dodaje przypadkowych ekranów. Domyka fundament przed budową APK testowego.

## Zmiany
- numer schematu danych `v6` w backupie;
- backup oznaczony jako Stage 6;
- ekran ustawień pokazuje wersję schematu;
- dodany automatyczny walidator projektu `validate_project.js`;
- skrypt `npm run validate` wykonuje kontrolę składni + kontrolę obecności kluczowych modułów;
- kontrola duplikatów ID w Diagnosis Core;
- zachowane: Kameleon, AMATOR/WARSZTAT, kartoteka pojazdów, historia, Diagnosis Core, elektryka, OBD, płyny/serwis, test przed/po naprawie.

## Walidacja wykonana
- `node --check App.js` — OK
- `node --check DiagnosisCore.js` — OK
- `node --check NAPRAWNIK_ELEKTRYKA_BAZA_v1.js` — OK
- walidator projektu — OK

## Następny etap
Po tym etapie sensowny następny krok to instalacja zależności Expo i pełny `expo export` / build APK w Codespaces.
