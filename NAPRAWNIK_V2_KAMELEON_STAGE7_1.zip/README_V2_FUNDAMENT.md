NAPRAWNIK V2 — FUNDAMENT + KAMELEON UI

Co zostało zrobione:
1. Diagnosis Core przeniesiony do osobnego DiagnosisCore.js.
2. Każdy węzeł diagnostyczny ma unikalne ID.
3. Dodany walidator grafu: duplikaty ID, brakujące przejścia, nieosiągalne węzły.
4. Naprawiona pętla CDI w diagnostyce braku iskry.
5. Dodane flow: utrata mocy po rozgrzaniu oraz 2T: iskra jest, ale nie odpala.
6. Dodane do drzewa: membrana/reed valve, uszczelniacze wału, zawieszenie, zegary/wskaźniki, ciśnienie/jakość oleju oraz „Żadna z powyższych”.
7. Baza elektryczna 50–250 cc podłączona do aplikacji jako Electrical Hub.
8. Limit Free dla kartotek korzysta teraz także z vehicles, a nie tylko z notatek/logów.
9. Historia diagnoz jest pokazywana w kartotece konkretnego pojazdu.
10. Backup zawiera wersję fundamentu i wersję Diagnosis Core.
11. UI dostało kierunek Kameleon: ciemne tło + gradient fiolet → magenta → pomarańczowy.
12. Home dostał hero NAPRAWNIK KAMELEON.

Nie zrobiono jeszcze:
- realnych płatności,
- finalnego systemu AMATOR/WARSZTAT,
- zdjęć przed/po,
- PDF raportów,
- OBD (celowo zostawione do późniejszej decyzji),
- pełnej bazy płynów/interwałów,
- finalnego APK produkcyjnego.

Walidacja:
- DiagnosisCore.js przechodzi node --check.
- Walidator grafu zwraca 0 błędów dla wszystkich 6 flow.
- App.js wymaga walidacji przez Expo/Metro/Babel w projekcie docelowym, ponieważ zawiera JSX.
