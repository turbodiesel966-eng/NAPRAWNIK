// NAPRAWNIK — BAZA INSTALACJI ELEKTRYCZNYCH v1
// Zakres: skutery i lekkie motocykle 50–250 cc.
// Uwaga: kolory/pinouty są wariantowe; przed podłączeniem konkretnego modelu
// trzeba potwierdzić DTR/schemat konkretnej wersji.

export const ELECTRICAL_DATABASE = {
  version: '1.0',
  scope: '50–250 cc',

  minimalStart: {
    title: 'Minimalna instalacja do uruchomienia silnika',
    variants: [
      { id:'2t_ac_cdi', name:'2T AC-CDI — test zapłonu', required:['stator/magneto','pickup','AC-CDI zgodny z instalacją','cewka WN','świeca/fajka','masa silnika','obwód gaszenia zgodny z CDI'], omit:['reflektory','kierunkowskazy','licznik','klakson','oświetlenie tablicy'], steps:['zidentyfikuj typ AC-CDI','potwierdź stator i pickup','połącz CDI zgodnie z właściwym pinoutem','zapewnij pewną masę','sprawdź iskrę','dopiero potem przejdź do paliwa/rozruchu'] },
      { id:'gy6_ac_cdi', name:'GY6 AC-CDI — minimum warsztatowe', required:['stator z cewką zasilającą CDI','pickup','AC-CDI','cewka WN','świeca/fajka','masa'], note:'W typowym AC-CDI energia zapłonu pochodzi z cewki statora; akumulator nie musi zasilać samego CDI.' },
      { id:'gy6_dc_cdi', name:'GY6 DC-CDI — minimum warsztatowe', required:['akumulator 12 V','bezpiecznik','zasilanie po stacyjce','DC-CDI','pickup','cewka WN','masa'], note:'DC-CDI wymaga prawidłowego zasilania z instalacji 12 V.' }
    ]
  },

  architecture: {
    title: 'Architektura instalacji',
    blocks: {
      power:['stator/magneto','akumulator','regulator/rectifier'],
      ignition:['pickup','CDI/ECU','cewka WN','świeca','kill circuit'],
      starting:['akumulator','bezpiecznik','stacyjka','START','przekaźnik rozrusznika','rozrusznik'],
      consumers:['światła','kierunkowskazy','STOP','klakson','licznik','pompa paliwa','wentylator'],
      safety:['kill switch','stopka','czujnik sprzęgła','czujniki hamulca','czujnik przechyłu','przekaźniki blokad']
    },
    rule:'Najpierw ustal, czy usterka dotyczy źródła energii, sterowania, odbiornika, masy czy zabezpieczenia.'
  },

  acDc: {
    title:'AC / DC — rozpoznanie i przebudowa',
    facts:[
      'AC i DC mogą współistnieć w jednym pojeździe.',
      'Nie każdy pojazd jest w całości AC albo w całości DC.',
      'Kolor przewodu nie jest wystarczającym dowodem jego funkcji.',
      'Typ regulatora, statora i CDI trzeba potwierdzić dla konkretnego wariantu.'
    ],
    identification:[
      'sprawdź zachowanie obwodu przy wyłączonym i pracującym silniku',
      'mierz napięcie na właściwym zakresie AC/DC',
      'ustal funkcję regulatora po schemacie, nie tylko po liczbie pinów',
      'zidentyfikuj uzwojenia statora'
    ],
    acToDc:{
      title:'AC → DC — ogólna architektura',
      steps:[
        'zidentyfikuj wszystkie obwody AC',
        'ustal, które uzwojenia statora są przeznaczone do ładowania/oświetlenia',
        'dobierz kompatybilny regulator/rectifier',
        'jeżeli konstrukcja wymaga zmiany połączeń statora — wykonaj ją według schematu konkretnej wersji',
        'prowadź wyprostowane/regulowane DC do akumulatora przez właściwy bezpiecznik',
        'zasil odbiorniki DC z chronionej szyny +12 V',
        'sprawdź masy i przekroje przewodów',
        'po przebudowie wykonaj pomiary napięcia ładowania i test odbiorników'
      ],
      mistakes:['AC bezpośrednio na akumulator','niekompatybilny regulator','brak bezpiecznika','łączenie uzwojeń statora bez identyfikacji','założenie wspólnej masy bez potwierdzenia','zmiana samego regulatora, gdy wymagane są zmiany statora'],
      validation:['polaryzacja','brak zwarcia +12 V do masy','napięcie ładowania na wolnych i podwyższonych obrotach','spadki napięcia','temperatura regulatora','bezpiecznik']
    },
    dcToAc:{
      title:'DC → AC — tylko po analizie źródła i odbiornika',
      steps:['określ wymagane napięcie odbiornika','sprawdź dostępne uzwojenie AC statora','sprawdź regulator i sposób prowadzenia masy','odseparuj AC od DC, jeśli konstrukcja tego wymaga','nie podawaj AC na elektronikę przeznaczoną dla DC','zmierz napięcie bez obciążenia i pod obciążeniem'],
      note:'Nie jest to zwykłe przepięcie przewodu. Parametry źródła i odbiornika muszą być zgodne.'
    }
  },

  charging: {
    title:'Ładowanie — stator → regulator → akumulator',
    chain:['stator/magneto','przewody','złącza','regulator/rectifier','bezpiecznik','przewód +','akumulator','masa'],
    tests:[
      'napięcie akumulatora w spoczynku',
      'napięcie ładowania przy pracy silnika',
      'napięcie AC ze statora według DTR',
      'spadek napięcia po stronie plusowej',
      'spadek napięcia po stronie masowej',
      'stan złączy i regulatora',
      'stan akumulatora pod obciążeniem'
    ],
    tree:[
      'brak ładowania → akumulator i bezpiecznik',
      'następnie → masa i połączenia',
      'następnie → wyjście statora',
      'jeżeli stator jest prawidłowy → regulator/rectifier',
      'następnie → przewód regulator–akumulator i spadki napięcia',
      'na końcu → sam akumulator'
    ],
    faults:['ładowanie tylko przy wysokich obrotach','zanik po rozgrzaniu','niestabilne ładowanie','przepalający się bezpiecznik','przegrzewający się regulator','za wysokie napięcie','dobre napięcie bez obciążenia, słabe pod obciążeniem','korozja złącza powodująca opór i grzanie']
  },

  ignition: {
    title:'Zapłon — AC-CDI / DC-CDI / EFI',
    acCdi:['świeca','fajka/przewód WN','cewka WN','masa','kill','pickup','cewka zasilająca CDI','CDI','złącza'],
    dcCdi:['akumulator','bezpiecznik','stacyjka','zasilanie DC-CDI','masa','pickup','cewka WN','kill','CDI'],
    efi:['akumulator','bezpieczniki','przekaźnik główny','ECU','pompa paliwa','wtryskiwacz','TPS','MAP/IAT zależnie od modelu','czujnik temperatury','czujnik położenia wału','czujnik przechyłu','lambda zależnie od modelu','wentylator','złącze diagnostyczne'],
    special:['iskra tylko na zimno','pickup traci sygnał po rozgrzaniu','cewka statora traci wydajność po rozgrzaniu','przebicie fajki/WN przy wilgoci','kill zwarty do masy','słaba masa','iskra widoczna poza silnikiem, ale problem pod obciążeniem']
  },

  starter: {
    title:'Rozrusznik i START',
    architecture:['akumulator → bezpiecznik → sterowanie','START → logika zabezpieczeń','przekaźnik → rozrusznik','masa silnika → akumulator'],
    cases:{
      noReaction:['akumulator','bezpiecznik','stacyjka','START','czujnik hamulca/sprzęgła','stopka','przekaźnik','masa'],
      clickNoCrank:['akumulator pod obciążeniem','przewód +','masa silnika','styki przekaźnika','rozrusznik'],
      slow:['akumulator','spadek napięcia +','spadek napięcia masy','przekaźnik','szczotki/komutator','opory mechaniczne'],
      spinsNoEngine:['bendix/jednokierunkowe sprzęgło','zębatki','zazębienie'],
      staysOn:['przekaźnik','START','wiązka','zwarcie sterowania']
    }
  },

  grounds: {
    title:'Masy i spadki napięcia',
    rules:['masa silnika musi mieć pewne połączenie','farba/korozja pod punktem masowym może powodować problemy','test ciągłości jest tylko wstępny — pod obciążeniem lepszy jest test spadku napięcia'],
    faults:['korozja oczka','farba pod masą','luźna śruba','pęknięty przewód','utleniona kostka','cienki przewód dający pozorną masę']
  },

  fusesRelays: {
    title:'Bezpieczniki i przekaźniki',
    rules:['bezpiecznik dobiera się do obwodu i przewodów','przepalający się bezpiecznik jest objawem, nie powodem do założenia większego','przekaźnik ma obwód sterowania i obwód mocy','sprawdź napięcie po obu stronach bezpiecznika pod obciążeniem'],
    relays:['starter','main','headlight','fuel pump','fan','indicator']
  },

  switches: ['stacyjka','kill switch','START','światła','kierunkowskazy','klakson','czujnik hamulca','czujnik sprzęgła','wyłącznik stopki'],

  lighting: {
    title:'Oświetlenie i sygnalizacja',
    systems:['mijania/drogowe','pozycja','tył','STOP','kierunkowskazy','tablica','licznik','klakson'],
    faults:['wszystko martwe → zasilanie/masa/bezpiecznik/stacyjka','jeden odbiornik → żarówka/LED/oprawka/przewód/masa','kierunkowskaz świeci stale → przerywacz/obciążenie/masa','miga za szybko → obciążenie/przerywacz/żarówka','STOP nie działa → przełączniki/zasilanie/masa/źródło światła','klakson nie działa → zasilanie/przycisk/masa/klakson'],
    led:['LED zmienia obciążenie obwodu','sprawdź kompatybilność przerywacza','nie dobieraj rezystora bez obliczenia mocy i temperatury']
  },

  efi: {
    title:'EFI 125/150/250',
    blocks:['akumulator','bezpieczniki','przekaźnik główny','ECU','pompa','wtryskiwacz','TPS','MAP/IAT','temperatura','CKP','czujnik przechyłu','lambda','wentylator','diagnostyka'],
    rule:'Przed podejrzeniem ECU sprawdź zasilania, masy, bezpieczniki, przekaźniki i sygnały wejściowe.'
  },

  swap: {
    title:'Swap silnika',
    checklist:['typ silnika','AC-CDI/DC-CDI/ECU','stator','regulator','rozrusznik','wymagane czujniki','kill','masy','ładowanie','odbiorniki'],
    mapping:['stator → regulator','stator/pickup → CDI/ECU','CDI/ECU → cewka WN','akumulator → bezpiecznik → szyna DC','szyna DC → stacyjka/przekaźnik','starter → relay → akumulator','silnik → masa'],
    rule:'Mapuj funkcję przewodu, a nie tylko jego kolor.'
  },

  workshopHarness: {
    title:'Instalacja warsztatowa',
    modes:{
      ignition:['stator/pickup','CDI/ECU','cewka WN','świeca','masa','gaszenie'],
      charging:['stator','regulator','bezpiecznik','akumulator','miernik'],
      starter:['akumulator','bezpiecznik','sterowanie','przekaźnik','rozrusznik'],
      full:['zapłon','ładowanie','rozrusznik','stacyjka','światła','STOP','kierunki','klakson','licznik','wentylator/pompa zależnie od modelu']
    },
    safety:'Obwód akumulatora powinien być zabezpieczony odpowiednim bezpiecznikiem; przewody muszą mieć odpowiedni przekrój, a połączenia izolację.'
  },

  measurement: {
    title:'Procedury pomiarowe',
    tests:['akumulator','ładowanie','AC statora','ciągłość','spadek napięcia masy','spadek napięcia plusa','bezpiecznik','przekaźnik','przełącznik','cewka WN','pickup','zasilanie CDI/ECU','pobór prądu po wyłączeniu','napięcie pod obciążeniem'],
    methodology:['oględziny','identyfikacja schematu','zasilanie','masa/spadek napięcia','pomiar elementu','potwierdzenie naprawy w warunkach usterki']
  },

  vehicleFamilies: ['50 2T','50 4T','70/75','80/90','100/110','125','150','200','250'],
  platforms: ['GY6','Minarelli 2T','Piaggio','Honda CG/CB i pochodne','Yamaha YBR/YZF/YFM i pochodne','Kymco','Zongshen'],

  sourceNotes: [
    'Yamaha YBR125 2008 service material — wiring, fuse, battery, starter, regulator, lighting/signaling.',
    'Yamaha YZF-R125 service manual — AC magneto, regulator/rectifier, ECU, starter, fuel pump, lean-angle sensor, lighting.',
    'Yamaha YW125Y 2009 service manual — electrical components and charging diagnosis.',
    'Yamaha SR125 1997 service manual — CDI magneto charging architecture and charging troubleshooting.',
    'Zongshen ZS250GY-3 service manual — 250 cc electrical architecture, power supply/control/consumption, fuse/battery and ignition diagnosis.',
    'Kymco Agility 50/125 and Like 50/125 service material — electrical systems and model-specific wiring.',
    'Piaggio Zip wiring/service material — multiple model-specific electrical diagrams.',
    'Public GY6 diagnostic material — AC-CDI vs DC-CDI distinction and ignition test order.'
  ]
};

export default ELECTRICAL_DATABASE;
