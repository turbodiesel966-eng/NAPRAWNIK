# NAPRAWNIK V2 — Kameleon Stage 4

Ten etap rozwija Stage 3 bez wyrzucania wcześniejszych funkcji.

## Dodane / dopracowane
- offline'owy słownik OBD P0xxx z wyszukiwaniem,
- kody P0300–P0304 oraz typowe kody czujników, mieszanki, zapłonu i zasilania,
- dostęp do OBD z ekranu głównego,
- profil stanu pojazdu w kartotece: liczba diagnoz, napraw, przypomnień, notatek i operacji oraz informacja o testach po naprawie,
- możliwość przypięcia bieżącej diagnostyki krok po kroku do wybranego pojazdu przed zapisaniem wyniku,
- backup oznaczony jako Stage 4.

## Zasady
- Kod OBD jest wskazówką, nie dowodem uszkodzenia konkretnej części.
- Nie wszystkie motocykle/skutery obsługują wszystkie kody P0xxx.
- Parametry, pinouty i wartości pomiarowe trzeba potwierdzać w DTR konkretnego modelu.

## Pliki
- `App.js` — główna aplikacja,
- `DiagnosisCore.js` — logika diagnostyki krok po kroku,
- `NAPRAWNIK_ELEKTRYKA_BAZA_v1.js` — baza elektryczna 50–250 cc.
