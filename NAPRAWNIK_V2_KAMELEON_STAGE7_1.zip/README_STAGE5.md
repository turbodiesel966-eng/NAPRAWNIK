# NAPRAWNIK V2 — Kameleon Stage 5 / Stabilizacja

## Co zostało uporządkowane
- jedno źródło prawdy dla limitu Free: kartoteka `vehicles`, a nie luźne wpisy VIN;
- wpis Czarna Skrzynka / Notatnik z VIN wymaga istniejącej kartoteki pojazdu;
- po utworzeniu pojazdu stare wpisy z takim samym VIN-em są automatycznie podpinane do `vehicleId`;
- zapis naprawy zachowuje pełny test przed/po: pytania, wyniki, status i uwagi;
- OBD rozszerzone o P0305–P0308 oraz kilka typowych kodów CKP/CMP, biegu jałowego, napięcia, alternatora, wtryskiwaczy i pompy paliwa;
- zachowano Kameleon, Diagnosis Core, bazę elektryczną, kartotekę, historię i tryby AMATOR/WARSZTAT.

## Walidacja
`npm run check` sprawdza składnię wszystkich trzech plików JavaScript.

## Ważne
Wartości techniczne i kody są wskazówkami diagnostycznymi. Pinouty, momenty, zakresy pomiarów i procedury należy potwierdzać w DTR konkretnego pojazdu.
