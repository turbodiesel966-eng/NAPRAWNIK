// NAPRAWNIK V2 — Diagnosis Core
// UI nie zawiera logiki grafu. Każdy węzeł ma unikalne ID, a przejścia są walidowalne.

export const DIAG_FLOWS = {
  noSpark: {
    title: 'Brak iskry na świecy',
    steps: [
      { id:'start', q:'Wykręć świecę, oprzyj gwint o masę silnika i zakręć rozrusznikiem. Czy jest wyraźna iskra?', yes:'spark', no:'coilPower', warn:'Nie trzymaj przewodu WN gołą ręką.' },
      { id:'coilPower', q:'Sprawdź zasilanie cewki i masę zgodnie ze schematem DTR. Czy zasilanie/masa są prawidłowe?', yes:'pickup', no:'wiring', expected:'Wartość zależna od typu CDI/ECU.' },
      { id:'pickup', q:'Sprawdź impulsator/pickup oraz jego przewody. Czy sygnał lub rezystancja mieści się w DTR?', yes:'kill', no:'pickupRepair', expected:'Użyj specyfikacji konkretnego silnika.' },
      { id:'kill', q:'Czy przewód gaszenia (kill) jest wolny od zwarcia do masy w momencie, gdy powinien być aktywny zapłon?', yes:'cdi', no:'killRepair' },
      { id:'wiring', q:'Sprawdź bezpiecznik, złącza, masę silnika i przewód WN. Czy znalazłeś przerwę lub zwarcie?', yes:'wiringRepair', no:'cdi' },
      { id:'spark', result:'ISKRA JEST', detail:'Układ zapłonowy podstawowo reaguje. Przejdź do paliwa, kompresji i ustawienia zapłonu.' },
      { id:'pickupRepair', result:'PODEJRZENIE: IMPULSATOR / JEGO OKABLOWANIE', detail:'Napraw lub wymień element dopiero po potwierdzeniu pomiaru wg DTR.' },
      { id:'killRepair', result:'PODEJRZENIE: OBWÓD KILL SWITCH / STACYJKA', detail:'Szukaj zwarcia przewodu gaszenia do masy.' },
      { id:'wiringRepair', result:'PODEJRZENIE: INSTALACJA', detail:'Usuń przerwę, korozję lub słabą masę i ponów próbę iskry.' },
      { id:'cdi', result:'PODEJRZENIE: CDI / ECU / CEWKA', detail:'Nie wymieniaj części w ciemno. Potwierdź zasilanie, masy, pickup i przewody.' }
    ]
  },
  charging: {
    title:'Brak / słabe ładowanie',
    steps:[
      { id:'start', q:'Zmierz napięcie akumulatora po postoju. Czy jest około 12,5 V lub więcej?', yes:'running', no:'battery' },
      { id:'running', q:'Uruchom silnik i zmierz napięcie na akumulatorze. Czy rośnie do ok. 13,8–14,6 V?', yes:'good', no:'stator' },
      { id:'stator', q:'Sprawdź AC z alternatora/statora oraz ciągłość przewodów według DTR. Czy stator daje prawidłowy sygnał?', yes:'regulator', no:'statorRepair' },
      { id:'regulator', q:'Sprawdź regulator, masę i złącza. Czy regulator jest prawidłowo zasilany i ma dobrą masę?', yes:'regRepair', no:'wiringRepair' },
      { id:'battery', result:'AKUMULATOR ROZŁADOWANY / DO SPRAWDZENIA', detail:'Naładuj i wykonaj ponowny pomiar. Niskie napięcie nie potwierdza jeszcze uszkodzenia akumulatora.' },
      { id:'good', result:'ŁADOWANIE W ZAKRESIE KONTROLNYM', detail:'Układ ładowania wygląda prawidłowo w tym teście.' },
      { id:'statorRepair', result:'PODEJRZENIE: STATOR / ALTERNATOR', detail:'Potwierdź pomiarem wg DTR konkretnego silnika.' },
      { id:'regRepair', result:'PODEJRZENIE: REGULATOR NAPIĘCIA', detail:'Sprawdź także temperaturę, masę i stan złączy.' },
      { id:'wiringRepair', result:'PODEJRZENIE: OKABLOWANIE / MASA', detail:'Oczyść i zabezpiecz połączenia, potem ponów pomiar.' }
    ]
  },
  starter: {
    title:'Rozrusznik tylko klika / nie kręci',
    steps:[
      { id:'start', q:'Czy światła/kontrolki wyraźnie przygasają przy próbie rozruchu?', yes:'battery', no:'relay' },
      { id:'battery', q:'Zmierz napięcie akumulatora podczas rozruchu. Czy nie spada nadmiernie?', yes:'starter', no:'batteryRepair', expected:'Dokładny próg zależy od układu i akumulatora; porównaj z DTR.' },
      { id:'relay', q:'Czy na wejściu/wyjściu przekaźnika rozrusznika pojawia się prawidłowe napięcie podczas START?', yes:'starter', no:'relayRepair' },
      { id:'starter', q:'Czy rozrusznik ma dobrą masę i połączenie plusowe, a silnik rozrusznika nie jest zablokowany?', yes:'starterRepair', no:'wiringRepair' },
      { id:'batteryRepair', result:'PODEJRZENIE: AKUMULATOR', detail:'Naładuj/przetestuj akumulator pod obciążeniem i sprawdź klemy.' },
      { id:'relayRepair', result:'PODEJRZENIE: PRZEKAŹNIK / STEROWANIE STARTEM', detail:'Sprawdź bezpiecznik, stacyjkę, czujniki blokady i przekaźnik.' },
      { id:'starterRepair', result:'PODEJRZENIE: ROZRUSZNIK', detail:'Sprawdź szczotki, komutator, łożyska i mechaniczne zablokowanie.' },
      { id:'wiringRepair', result:'PODEJRZENIE: PRZEWODY / MASA', detail:'Sprawdź spadek napięcia na przewodzie plusowym i masowym.' }
    ]
  },
  compression: {
    title:'Podejrzenie niskiej kompresji',
    steps:[
      { id:'start', q:'Czy silnik ma wyraźnie mniejszy opór podczas kręcenia niż zwykle?', yes:'test', no:'other' },
      { id:'test', q:'Wykonaj próbę kompresji zgodnie z procedurą dla danego silnika. Czy wynik jest poza zakresem DTR?', yes:'wet', no:'other' },
      { id:'wet', q:'Wykonaj próbę olejową. Czy po dodaniu niewielkiej ilości oleju wynik wyraźnie wzrasta?', yes:'rings', no:'valves' },
      { id:'rings', result:'PODEJRZENIE: PIERŚCIENIE / CYLINDER / TŁOK', detail:'Wymaga dalszej kontroli mechanicznej.' },
      { id:'valves', result:'PODEJRZENIE: ZAWORY / USZCZELNIENIE GŁOWICY', detail:'Sprawdź luz zaworowy i szczelność zgodnie z DTR.' },
      { id:'other', result:'KOMPRESJA NIE POTWIERDZA USTERKI W TYM TEŚCIE', detail:'Sprawdź zapłon, paliwo, dolot i ustawienie rozrządu.' }
    ]
  },
  hotLoss: {
    title:'Traci moc po rozgrzaniu',
    steps:[
      { id:'start', q:'Czy usterka pojawia się dopiero po rozgrzaniu i częściowo znika po kilku minutach postoju?', yes:'ignition', no:'other' },
      { id:'ignition', q:'Czy iskra podczas usterki jest nadal wyraźna, a pickup/cewka/WN zostały sprawdzone na gorąco?', yes:'fuel', no:'ignitionRepair' },
      { id:'fuel', q:'Czy po wystąpieniu usterki przepływ paliwa i odpowietrzenie zbiornika są prawidłowe?', yes:'compression', no:'fuelRepair' },
      { id:'compression', q:'Czy kompresja na zimno i na gorąco pozostaje prawidłowa wg DTR?', yes:'valves', no:'compressionRepair' },
      { id:'valves', result:'SPRAWDŹ ZAWORY / ROZRZĄD NA GORĄCO', detail:'W 4T zmiana luzu po temperaturze może zmieniać pracę silnika.' },
      { id:'ignitionRepair', result:'PODEJRZENIE: USTERKA ZAPŁONU NA GORĄCO', detail:'Porównaj pickup, cewkę, fajkę, przewód WN i zasilanie modułu w czasie wystąpienia usterki.' },
      { id:'fuelRepair', result:'PODEJRZENIE: ZASILANIE PALIWEM / ODPOWIETRZENIE', detail:'Sprawdź kranik, filtr, przewód, podciśnienie, odpowietrzenie baku i poziom paliwa.' },
      { id:'compressionRepair', result:'PODEJRZENIE: SPADek KOMPRESJI NA GORĄCO', detail:'Dalsza kontrola mechaniczna: pierścienie, cylinder, zawory lub uszczelnienie.' },
      { id:'other', result:'OBJAW NIE POTWIERDZONY W TYM FLOW', detail:'Przejdź do pełnej diagnostyki objawu.' }
    ]
  },
  twoStrokeNoStart: {
    title:'2T: jest iskra, ale nie chce zapalić',
    steps:[
      { id:'start', q:'Czy świeca po próbie rozruchu jest wyraźnie mokra od paliwa?', yes:'flooded', no:'fuel' },
      { id:'fuel', q:'Czy paliwo dociera do gaźnika, a dysze i obwód biegu jałowego są drożne?', yes:'reeds', no:'fuelRepair' },
      { id:'reeds', q:'Czy membrana/reed valve zamyka się prawidłowo i nie ma pękniętych listków ani dużych szczelin?', yes:'seals', no:'reedRepair' },
      { id:'seals', q:'Czy są podstawy, by podejrzewać nieszczelność uszczelniaczy wału korbowego?', yes:'sealRepair', no:'compression' },
      { id:'flooded', q:'Po osuszeniu świecy i kontroli gaźnika silnik nadal się zalewa?', yes:'carbRepair', no:'compression' },
      { id:'compression', q:'Czy kompresja jest prawidłowa dla tego silnika?', yes:'timing', no:'compressionRepair' },
      { id:'timing', result:'SPRAWDŹ USTAWIENIE ZAPŁONU / KLIN KOŁA MAGNETYCZNEGO', detail:'Przesunięty zapłon może dawać iskrę, ale silnik nie podejmie pracy prawidłowo.' },
      { id:'fuelRepair', result:'PODEJRZENIE: ZASILANIE PALIWEM / GAŹNIK', detail:'Sprawdź przepływ, poziom paliwa, dysze, ssanie i szczelność dolotu.' },
      { id:'reedRepair', result:'PODEJRZENIE: MEMBRANA / REED VALVE', detail:'Sprawdź listki, gniazdo i kierunek montażu.' },
      { id:'sealRepair', result:'PODEJRZENIE: USZCZELNIACZE WAŁU', detail:'Nieszczelność skrzyni korbowej w 2T może uniemożliwiać prawidłowe zasysanie mieszanki.' },
      { id:'carbRepair', result:'PODEJRZENIE: PRZELEWANIE / SSANIE / POZIOM PALIWA', detail:'Sprawdź zaworek iglicowy, pływak, ssanie automatyczne i ustawienie gaźnika.' },
      { id:'compressionRepair', result:'PODEJRZENIE: KOMPRESJA / CYLINDER / TŁOK', detail:'Potwierdź pomiarem i kontrolą mechaniczną.' }
    ]
  }
};

export function getDiagStep(flowId, stepId) {
  const flow = DIAG_FLOWS[flowId];
  if (!flow) return null;
  return flow.steps.find(step => step.id === stepId) || flow.steps[0] || null;
}

export function validateDiagFlows(flows = DIAG_FLOWS) {
  const errors = [];
  Object.entries(flows).forEach(([flowId, flow]) => {
    const ids = new Set();
    flow.steps.forEach(step => {
      if (!step.id) errors.push(`${flowId}: node bez id`);
      else if (ids.has(step.id)) errors.push(`${flowId}: duplikat id ${step.id}`);
      else ids.add(step.id);
    });
    const start = flow.steps[0]?.id;
    const reachable = new Set(start ? [start] : []);
    let changed = true;
    while (changed) {
      changed = false;
      flow.steps.forEach(step => {
        if (!reachable.has(step.id)) return;
        ['yes','no'].forEach(key => {
          if (step[key] && !ids.has(step[key])) errors.push(`${flowId}:${step.id} → ${key}:${step[key]} nie istnieje`);
          if (step[key] && ids.has(step[key]) && !reachable.has(step[key])) { reachable.add(step[key]); changed = true; }
        });
      });
    }
    flow.steps.forEach(step => {
      if (!reachable.has(step.id)) errors.push(`${flowId}: nieosiągalny node ${step.id}`);
    });
  });
  return errors;
}
