import React, { useState, useEffect, useCallback } from 'react';
import {
  SafeAreaView, View, Text, ScrollView, TouchableOpacity, TextInput, Image,
  StyleSheet, StatusBar, Alert, Share
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import * as ImagePicker from 'expo-image-picker';
import { Accelerometer, Gyroscope, LightSensor } from 'expo-sensors';
import { DIAG_FLOWS, getDiagStep, validateDiagFlows } from './DiagnosisCore';
import { ELECTRICAL_DATABASE } from './NAPRAWNIK_ELEKTRYKA_BAZA_v1';

// ---------- DANE ----------
const TORQUE = {
  '2T': [['Świeca zapłonowa', '12-15'], ['Głowica cylindra (na krzyż)', '18-20'], ['Koło magnetowe', '40-50'], ['Śruby miski/pokrywy', '8-10'], ['Nakrętka koła zębatego', '35-45']],
  '4T': [['Świeca zapłonowa', '20-25'], ['Śruby głowicy (na krzyż, etapami)', '25-30'], ['Śruba spustowa oleju', '20-25'], ['Nakrętka koła zamachowego', '50-60'], ['Śruby miski olejowej', '9-11']],
  'CVT': [['Nakrętka koła pasowego (przód)', '40-50'], ['Nakrętka sprzęgła (tył)', '55-65'], ['Śruby pokrywy CVT', '9-11'], ['Śruba koła pasowego wtórnego', '40-45']],
};

const WIRING = {
  '2T': {
    obwody: [
      ['Zapłon (magneto)', 'Cewka zapłonowa → kondensator → przerywacz/CDI → świeca. W starszych modelach brak akumulatora — zapłon zasilany bezpośrednio z cewki.'],
      ['Oświetlenie (AC z cewki)', 'Osobna cewka oświetleniowa w alternatorze zasila światła bezpośrednio prądem zmiennym — jasność zależy od obrotów silnika.'],
      ['Rozrusznik / kick-start', 'W wersjach z rozrusznikiem elektrycznym: akumulator → bezpiecznik → przekaźnik → silnik rozrusznika.'],
    ],
    kolory: [['Czarny', 'Masa (–)'], ['Żółty', 'Ładowanie / oświetlenie z cewki (AC)'], ['Niebiesko-biały', 'Impuls zapłonu do CDI'], ['Czerwony', 'Plus stały z akumulatora (jeśli występuje)']],
  },
  '4T': {
    obwody: [
      ['Ładowanie', 'Alternator (3-fazowy AC) → prostownik/regulator napięcia → akumulator. Najczęstsza przyczyna braku ładowania: uszkodzony regulator.'],
      ['Zapłon (CDI/ECU)', 'Czujnik położenia wału → moduł CDI/ECU → cewka zapłonowa → świeca.'],
      ['Rozrusznik', 'Akumulator → bezpiecznik główny → stycznik rozrusznika → silnik rozrusznika → masa.'],
      ['Wtrysk (jeśli występuje)', 'ECU steruje pompą paliwa, wtryskiwaczem i przepustnicą na podstawie czujników (TPS, temperatura, obroty).'],
    ],
    kolory: [['Żółty (x3)', 'Fazy alternatora (AC, przed prostownikiem)'], ['Zielony', 'Masa'], ['Czerwony', 'Plus stały z akumulatora'], ['Różowy/brązowy', 'Zasilanie po stacyjce']],
  },
  'CVT': {
    obwody: [
      ['Ładowanie', 'Jak w 4T: alternator → regulator/prostownik → akumulator. Skutery są bardziej czułe na spadek napięcia (dużo elektroniki).'],
      ['Immobilizer / blokada kierownicy', 'Cewka w stacyjce komunikuje się z modułem — uszkodzenie uniemożliwia odpalenie mimo sprawnego zapłonu.'],
      ['Czujniki CVT (wybrane modele)', 'Niektóre skutery mają czujnik prędkości/obrotów wtórnego koła pasowego do komputera pokładowego.'],
      ['Zapłon (CDI/ECU)', 'Jak w 4T — moduł steruje momentem zapłonu na podstawie czujnika położenia wału.'],
    ],
    kolory: [['Żółty', 'Fazy ładowania (AC)'], ['Zielony/czarny', 'Masa'], ['Czerwony', 'Plus stały z akumulatora'], ['Niebieski', 'Sygnał immobilizera (jeśli występuje)']],
  },
};



// ---------- ROZBUDOWANA DIAGNOSTYKA KROK PO KROKU ----------
const DIAG_TREE = [
  { label: 'Silnik nie odpala', children: [
    { label: 'W ogóle nie reaguje (rozrusznik/kick nic nie robi)', causes: ['Rozładowany akumulator', 'Przepalony bezpiecznik główny', 'Przerwany obwód masy', 'Uszkodzony stycznik rozrusznika'] },
    { label: 'Kręci, ale nie zapala', children: [
      { label: 'Brak iskry na świecy', causes: ['Uszkodzona cewka zapłonowa', 'Uszkodzony moduł CDI', 'Zwarcie w przewodzie wysokiego napięcia', 'Uszkodzony wyłącznik awaryjny (kill switch)'] },
      { label: 'Jest iskra, ale nie chce zapalić', causes: ['Zalany gaźnik/wtryskiwacz', 'Brak paliwa w komorze pływakowej', 'Zapchany filtr paliwa', 'Zła mieszanka paliwowa (2T)', 'Nieszczelne uszczelniacze wału korbowego (2T)', 'Uszkodzona lub nieszczelna membrana/reed valve (2T)'] },
    ]},
    { label: 'Odpala i od razu gaśnie', causes: ['Zbyt uboga/bogata mieszanka biegu jałowego', 'Nieszczelność kolektora ssącego', 'Zapchany filtr powietrza'] },
    { label: 'Rozrusznik kręci bardzo wolno', causes: ['Słaby/rozładowany akumulator', 'Zużyte szczotki rozrusznika', 'Zła masa silnik-rama'] },
  ]},
  { label: 'Silnik dymi', children: [
    { label: 'Dym niebieszawy', causes: ['Zużyte pierścienie tłokowe', 'Zbyt bogata mieszanka oleju (2T)', 'Zużyte uszczelniacze wałka korbowego'] },
    { label: 'Dym biały (gęsty)', causes: ['Woda w komorze spalania', 'Uszkodzona uszczelka pod głowicą', 'Kondensacja przy zimnym rozruchu (norma w małej ilości)'] },
    { label: 'Dym czarny', causes: ['Zbyt bogata mieszanka', 'Zapchany filtr powietrza', 'Źle ustawiony gaźnik/wtrysk'] },
  ]},
  { label: 'Nierówna praca / gaśnie na jałowym', children: [
    { label: 'Tylko na zimnym silniku', causes: ['Zła regulacja ssania/chokea', 'Zbyt uboga mieszanka rozruchowa'] },
    { label: 'Tylko na gorącym silniku', causes: ['Nieszczelność podciśnieniowa', 'Zapowietrzenie układu paliwowego', 'Źle wyregulowane zawory (4T)'] },
  ]},
  { label: 'Przegrzewanie się silnika', children: [
    { label: 'Chłodzenie cieczą', causes: ['Niski poziom płynu chłodzącego', 'Zapchany radiator', 'Uszkodzona pompa wody', 'Wadliwy termostat'] },
    { label: 'Chłodzenie powietrzem', causes: ['Zabrudzone żeberka cylindra', 'Zbyt uboga mieszanka', 'Zły kąt wyprzedzenia zapłonu'] },
  ]},
  { label: 'CVT: szarpanie / poślizg / słabe przyspieszenie', children: [
    { label: 'Szarpanie przy ruszaniu', causes: ['Zużyte okładziny sprzęgła odśrodkowego', 'Zaolejone sprzęgło'] },
    { label: 'Poślizg paska przy przyspieszaniu', causes: ['Rozciągnięty/zużyty pasek CVT', 'Zużyte rolki wariatora', 'Zaolejony pasek'] },
    { label: "Silnik 'wyje' bez przełożenia mocy", causes: ['Zerwany pasek CVT', 'Uszkodzone sprzęgło jednokierunkowe (startowe)'] },
  ]},
  { label: 'Elektryka: brak zasilania / kontrolki', children: [
    { label: 'Nic się nie świeci', causes: ['Przepalony bezpiecznik główny', 'Rozładowany/uszkodzony akumulator', 'Przerwana masa'] },
    { label: 'Akumulator się nie ładuje', causes: ['Uszkodzony regulator napięcia', 'Zużyte szczotki alternatora', 'Luźne złącze ładowania'] },
    { label: 'Pojedyncza kontrolka/element nie działa', causes: ['Przepalona żarówka/dioda', 'Lokalnie przepalony bezpiecznik', 'Uszkodzone złącze'] },
  ]},
  { label: 'Hamulce', children: [
    { label: 'Piszczą / zgrzytają podczas hamowania', causes: ['Zużyte klocki/okładziny (do wymiany)', 'Zabrudzona/zaszklona tarcza', 'Brak smaru na sworzniach zacisku'] },
    { label: 'Dźwignia/pedał hamulca jest miękki, gąbczasty', causes: ['Powietrze w układzie (odpowietrzyć)', 'Wyciek płynu hamulcowego', 'Zużyty przewód hamulcowy'] },
    { label: 'Hamulec ciągnie w jedną stronę', causes: ['Zapieczony tłoczek zacisku', 'Nierówne zużycie klocków', 'Zapowietrzony jeden obwód'] },
  ]},
  { label: 'Dziwne dźwięki / stukanie', children: [
    { label: 'Metaliczne stukanie z silnika', causes: ['Luz na sworzniu tłokowym', 'Zużyty łańcuch/napinacz rozrządu', 'Zbyt niski poziom oleju'] },
    { label: 'Stukanie z zawieszenia przy nierównościach', causes: ['Zużyte tuleje wahacza', 'Poluzowane mocowanie amortyzatora', 'Uszkodzony łącznik stabilizatora'] },
    { label: 'Pisk paska napędowego/generatora', causes: ['Zużyty lub rozciągnięty pasek', 'Nieprawidłowy naciąg paska', 'Zaolejony pasek'] },
  ]},
  { label: 'Zapach spalin / paliwa', children: [
    { label: 'Silny zapach benzyny przy postoju', causes: ['Wyciek z przewodu paliwowego', 'Nieszczelny korek/odpowietrznik baku', 'Przelewający się gaźnik'] },
    { label: 'Zapach spalin czuć podczas jazdy', causes: ['Nieszczelność w układzie wydechowym', 'Pęknięty kolektor wydechowy', 'Uszkodzona uszczelka tłumika'] },
  ]},
  { label: 'Sprzęgło (jednostki manualne)', children: [
    { label: 'Sprzęgło się ślizga (silnik "podkręca", brak mocy)', causes: ['Zużyte okładziny sprzęgła', 'Rozregulowany mechanizm sprzęgła', 'Zaolejone tarcze cierne'] },
    { label: 'Sprzęgło łapie bardzo wysoko lub nisko', causes: ['Rozregulowana linka/hydraulika sprzęgła', 'Powietrze w układzie hydraulicznym', 'Zużyta linka sprzęgłowa'] },
  ]},
  { label: 'Skrzynia biegów (manualna)', children: [
    { label: 'Trudno wrzucić bieg', causes: ['Rozregulowane sprzęgło', 'Zbyt gęsty/niewłaściwy olej przekładniowy', 'Zużyty mechanizm zmiany biegów'] },
    { label: 'Bieg samoczynnie wypada', causes: ['Zużyte widełki zmiany biegów', 'Zużyte zęby sprzęgające koła zębatego', 'Poluzowany mechanizm selektora'] },
    { label: 'Głośna praca skrzyni (wycie/zgrzyty)', causes: ['Niski poziom oleju przekładniowego', 'Zużyte łożyska skrzyni', 'Zużyte koła zębate'] },
  ]},
  { label: 'Opony i koła', children: [
    { label: 'Wibracje przy większej prędkości', causes: ['Niewyważone koło', 'Uszkodzona/odkształcona felga', 'Zużyta lub uszkodzona opona'] },
    { label: 'Nierówne zużycie bieżnika', causes: ['Złe ciśnienie w oponie', 'Zły kąt geometrii/ustawienia zawieszenia', 'Uszkodzone łożysko koła'] },
    { label: 'Koło "bije", kierownica drży', causes: ['Niewyważone koło', 'Wygięta oś/widelec', 'Luz na łożysku koła'] },
  ]},
  { label: 'Układ kierowniczy', children: [
    { label: 'Wyczuwalny luz na kierownicy', causes: ['Poluzowany stery główki ramy', 'Zużyte łożyska kierowania', 'Luz w przegubach układu kierowniczego'] },
    { label: 'Kierownica skręca się ciężko', causes: ['Zbyt mocno dokręcone łożyska stery', 'Brak smarowania łożysk stery', 'Zbyt niskie ciśnienie w oponie przedniej'] },
  ]},
  { label: 'Kontrolka silnika / błąd na wyświetlaczu', children: [
    { label: 'Kontrolka świeci światłem ciągłym', causes: ['Zapisany kod usterki czujnika (do odczytu skanerem OBD)', 'Luźne złącze czujnika', 'Nieszczelność układu (np. lambda/powietrze)'] },
    { label: 'Kontrolka miga', causes: ['Poważniejsza usterka zapłonu/wtrysku — unikać dalszej jazdy', 'Możliwe uszkodzenie katalizatora przy dalszej eksploatacji'] },
  ]},
  { label: 'Głośna praca układu wydechowego', children: [
    { label: 'Warkot/terkotanie na całym zakresie obrotów', causes: ['Nieszczelność między kolektorem a tłumikiem', 'Przerdzewiała komora tłumika', 'Poluzowane mocowanie wydechu'] },
    { label: 'Trzaski/strzały przy zwalnianiu gazu', causes: ['Zbyt uboga mieszanka', 'Nieszczelność na dolocie powietrza', 'Źle ustawiony zapłon'] },
  ]},
  { label: 'Zawieszenie', children: [
    { label: 'Stuki na nierównościach', causes: ['Luz w łożyskach główki ramy', 'Luźne mocowanie amortyzatora', 'Zużyte tuleje/wahacz', 'Luz w osi koła'] },
    { label: 'Niestabilność / ściąganie', causes: ['Nieprawidłowe ciśnienie opon', 'Luz łożyska koła', 'Krzywa felga/oś', 'Problem z geometrią lub widelcem'] },
  ]},
  { label: 'Wskaźniki i zegary', children: [
    { label: 'Prędkościomierz nie działa', causes: ['Czujnik/linka prędkości', 'Złącze lub przewód', 'Zasilanie licznika', 'Uszkodzenie samego licznika'] },
    { label: 'Obrotomierz wariuje', causes: ['Sygnał zapłonu', 'Masa/zasilanie', 'Zakłócenia lub złe podłączenie po modyfikacji'] },
  ]},
  { label: 'Ciśnienie i jakość oleju', children: [
    { label: 'Kontrolka oleju świeci', causes: ['Niski poziom oleju', 'Czujnik ciśnienia', 'Przewód czujnika', 'Rzeczywiście niskie ciśnienie — nie kontynuować jazdy bez weryfikacji'] },
    { label: 'Olej bardzo szybko ciemnieje / pachnie paliwem', causes: ['Przegrzewanie lub ciężkie warunki pracy', 'Przedostawanie się paliwa do oleju', 'Niewłaściwy olej lub interwał serwisowy'] },
  ]},
  { label: 'Żadna z powyższych nie pasuje?', causes: ['Zapisz dokładny objaw, temperaturę, obroty i warunki wystąpienia', 'Sprawdź podstawy: zasilanie, masa, paliwo, zapłon, kompresja', 'Przejdź do Diagnostyki krok po kroku i utwórz własną hipotezę'] },
];

const ELECTRIC_CHECKS = [
  'Akumulator: napięcie spoczynkowe min. 12.5V',
  'Ładowanie: 13.8-14.6V na biegu jałowym',
  'Bezpieczniki: sprawdź ciągłość, nie na wygląd',
  'Masa: styki czyste, dokręcone, bez korozji',
  'Regulator napięcia: częsta przyczyna braku ładowania',
  'Cewka zapłonowa: rezystancja wg DTR',
];

const PARTS_PRICES = [
  ['Klocki hamulcowe', 35, 65, 110], ['Filtr powietrza', 20, 40, 80], ['Świeca zapłonowa', 15, 30, 55],
  ['Pasek CVT', 35, 70, 120], ['Rolki wariatora (komplet)', 30, 60, 100], ['Olej silnikowy 1L', 18, 32, 50],
  ['Bezpieczniki (zestaw)', 10, 18, 30], ['Uszczelka pod głowicę', 25, 45, 75],
];

const OBD_CODES = [
  ['P0100','MAF/VAF — obwód pomiaru przepływu powietrza','Sprawdź zasilanie, masę, złącze i sygnał czujnika; nie zakładaj od razu uszkodzenia MAF.'],
  ['P0101','MAF/VAF — zakres lub działanie poza oczekiwaniem','Porównaj odczyt z warunkami pracy, sprawdź dolot i szczelność układu.'],
  ['P0110','IAT — obwód czujnika temperatury powietrza','Sprawdź przewody, złącze i zmianę rezystancji/napięcia zgodnie z DTR.'],
  ['P0115','ECT — obwód czujnika temperatury silnika','Sprawdź czujnik, wiązkę i wartości dla temperatury rzeczywistej.'],
  ['P0120','TPS — obwód czujnika położenia przepustnicy','Sprawdź zasilanie 5 V, masę i płynność sygnału podczas ruchu przepustnicy.'],
  ['P0130','Sonda lambda — obwód/sygnał','Sprawdź zasilanie grzałki, masę, nieszczelność wydechu i sygnał sondy.'],
  ['P0171','Mieszanka zbyt uboga (bank 1)','Sprawdź lewe powietrze, paliwo, ciśnienie/przepływ paliwa i pomiary czujników.'],
  ['P0172','Mieszanka zbyt bogata (bank 1)','Sprawdź ciśnienie paliwa, wtrysk, filtr powietrza i odczyty czujników.'],
  ['P0300','Wypadanie zapłonów — losowe/wielokrotne','Najpierw potwierdź zapłon, paliwo, kompresję i synchronizację; kod nie wskazuje automatycznie jednej części.'],
  ['P0301','Wypadanie zapłonu — cylinder 1','Sprawdź świecę, cewkę, wtrysk, kompresję i instalację cylindra 1.'],
  ['P0302','Wypadanie zapłonu — cylinder 2','Sprawdź świecę, cewkę, wtrysk, kompresję i instalację cylindra 2.'],
  ['P0303','Wypadanie zapłonu — cylinder 3','Sprawdź świecę, cewkę, wtrysk, kompresję i instalację cylindra 3.'],
  ['P0304','Wypadanie zapłonu — cylinder 4','Sprawdź świecę, cewkę, wtrysk, kompresję i instalację cylindra 4.'],
  ['P0305','Wypadanie zapłonu — cylinder 5','Dotyczy silników wielocylindrowych; sprawdź świecę, cewkę, wtrysk, kompresję i instalację cylindra 5.'],
  ['P0306','Wypadanie zapłonu — cylinder 6','Dotyczy silników wielocylindrowych; sprawdź świecę, cewkę, wtrysk, kompresję i instalację cylindra 6.'],
  ['P0307','Wypadanie zapłonu — cylinder 7','Dotyczy silników wielocylindrowych; sprawdź świecę, cewkę, wtrysk, kompresję i instalację cylindra 7.'],
  ['P0308','Wypadanie zapłonu — cylinder 8','Dotyczy silników wielocylindrowych; sprawdź świecę, cewkę, wtrysk, kompresję i instalację cylindra 8.'],
  ['P0335','Czujnik położenia wału CKP — obwód','Sprawdź zasilanie/sygnał CKP, przewody, szczelinę i element impulsujący zgodnie z DTR.'],
  ['P0340','Czujnik położenia wałka CMP — obwód','Jeśli silnik ma CMP, sprawdź zasilanie, masę, sygnał i synchronizację wg DTR.'],
  ['P0505','Układ regulacji biegu jałowego','Sprawdź przepustnicę, IAC/sterowanie biegiem jałowym, lewe powietrze i zasilanie.'],
  ['P0560','Napięcie układu — usterka obwodu','Sprawdź akumulator, ładowanie, masy, bezpieczniki i spadki napięcia.'],
  ['P0620','Obwód sterowania alternatora/generatora','Sprawdź regulator/sterowanie ładowaniem, przewody i zasilanie zgodnie z architekturą danego ECU.'],
  ['P0201','Wtryskiwacz cylindra 1 — obwód','Sprawdź zasilanie, sterowanie ECU, rezystancję wtryskiwacza i wiązkę.'],
  ['P0202','Wtryskiwacz cylindra 2 — obwód','Sprawdź zasilanie, sterowanie ECU, rezystancję wtryskiwacza i wiązkę.'],
  ['P0203','Wtryskiwacz cylindra 3 — obwód','Sprawdź zasilanie, sterowanie ECU, rezystancję wtryskiwacza i wiązkę.'],
  ['P0204','Wtryskiwacz cylindra 4 — obwód','Sprawdź zasilanie, sterowanie ECU, rezystancję wtryskiwacza i wiązkę.'],
  ['P0230','Pompa paliwa — obwód pierwotny','Sprawdź bezpiecznik, przekaźnik, zasilanie pompy, masę i sterowanie ECU.'],
  ['P0351','Cewka zapłonowa A — obwód pierwotny/wtórny','Sprawdź zasilanie, sterowanie ECU/CDI, cewkę, masę i przewody.'],
  ['P0420','Skuteczność katalizatora poniżej progu','Najpierw sprawdź zapłon, mieszankę, sondy i nieszczelności; nie wymieniaj katalizatora wyłącznie na podstawie kodu.'],
  ['P0500','Czujnik prędkości pojazdu — sygnał','Sprawdź czujnik, magnes/impulsator, przewody, zasilanie i licznik/ECU.'],
  ['P0562','Niskie napięcie układu','Sprawdź akumulator pod obciążeniem, ładowanie, masy i spadki napięcia.'],
  ['P0601','Błąd pamięci/oprogramowania modułu sterującego','Sprawdź zasilanie i masy modułu oraz komunikację; dalsza procedura zależy od producenta.'],
];

const FREE_VIN_LIMIT = 3;
const PRO_PRICE = '19 zł/mies.';
const PLAN_FEATURES = [
  ['Kalkulator mieszanki 2T', true, true],
  ['Diagnostyka, momenty dokręcania, instalacje', true, true],
  ['Czarna Skrzynka / Notatnik', `do ${FREE_VIN_LIMIT} pojazdów (VIN)`, 'bez limitu'],
  ['Zdjęcia w kartotekach pojazdu', false, 'wkrótce'],
  ['Generator raportu PDF dla klienta', false, 'wkrótce'],
  ['Magazyn części z kalkulacją marży', false, 'wkrótce'],
];

const CHECKLIST_ITEMS = [
  'Poziom i stan oleju silnikowego', 'Naciąg i stan łańcucha/paska napędu', 'Ciśnienie i stan opon',
  'Działanie hamulców (przód/tył)', 'Luz na łożyskach kół', 'Stan i naciąg linek/hydrauliki sprzęgła',
  'Działanie oświetlenia i sygnału', 'Poziom płynu chłodzącego/hamulcowego',
  'Stan i naciąg paska CVT (jeśli dotyczy)', 'Dokręcenie kluczowych śrub (patrz: Dane/Nm)',
];

const REWARDS = [
  { pts: 10, label: '5% zniżki na następną usługę' },
  { pts: 25, label: 'Darmowa wymiana świecy' },
  { pts: 50, label: 'Darmowy przegląd podstawowy' },
  { pts: 100, label: '15% zniżki na części' },
];


// ---------- PROFILE KONKRETNYCH SILNIKÓW ----------
const ENGINE_PROFILES = [
  {id:'am6', name:'Minarelli AM6', family:'2T / manual', info:'6-biegowy 2T, popularny w motorowerach z manualną skrzynią.', torque:[['Świeca','12–15 Nm'],['Głowica','12–14 Nm'],['Koło magnetowe','40–45 Nm'],['Nakrętka sprzęgła','45–50 Nm']], checks:['iskra / CDI / pickup','kompresja','gaźnik i dolot','olej przekładniowy','luz i regulacja sprzęgła']},
  {id:'mh', name:'Minarelli Horizontal', family:'2T / CVT', info:'Poziomy Minarelli stosowany w wielu skuterach.', torque:[['Świeca','12–15 Nm'],['Wariator','40–45 Nm'],['Dzwon sprzęgła','40–45 Nm'],['Spust przekładni','15 Nm']], checks:['pasek i rolki CVT','sprzęgło','gaźnik / podciśnienie','stator / CDI','przekładnia końcowa']},
  {id:'piaggio', name:'Piaggio Hi-Per2', family:'2T / CVT', info:'2T Piaggio z przekładnią CVT.', torque:[['Świeca','12–15 Nm'],['Wariator','45–50 Nm'],['Dzwon sprzęgła','45–50 Nm'],['Koło magnetowe','40 Nm']], checks:['CVT','gaźnik / dolot','zapłon','ładowanie','przekładnia']},
  {id:'gy50', name:'GY6 50', family:'4T / CVT', info:'Chiński 4T 50 cm³, najczęściej z automatycznym CVT.', torque:[['Świeca','12–15 Nm'],['Wariator','55–60 Nm'],['Dzwon sprzęgła','50–55 Nm'],['Nakrętki głowicy','22–25 Nm']], checks:['luz zaworowy','olej silnikowy','CVT','ładowanie','gaźnik / podciśnienie']},
  {id:'gy125', name:'GY6 125/150', family:'4T / CVT', info:'Popularna rodzina 4T 125/150 cm³.', torque:[['Świeca','12–15 Nm'],['Wariator','55–60 Nm'],['Dzwon sprzęgła','50–55 Nm'],['Nakrętki głowicy','22–25 Nm']], checks:['luz zaworowy','rozrząd','olej','CVT','ładowanie']},
  {id:'zongshen', name:'Zongshen 125/250', family:'4T / manual', info:'Jednocylindrowe 4T stosowane m.in. w lekkich motocyklach.', torque:[['Świeca','wg DTR'],['Głowica','wg DTR'],['Spust oleju','20 Nm orientacyjnie'],['Mocowanie silnika','45 Nm orientacyjnie']], checks:['luz zaworowy','łańcuch rozrządu','olej','sprzęgło','ładowanie']},
];

const MULTIMETER_PROCEDURES = [
 {title:'Akumulator — napięcie spoczynkowe',steps:['Wyłącz silnik i odbiorniki.','Ustaw multimetr na V DC.','Czerwony przewód na + akumulatora, czarny na −.','Odczytaj napięcie po postoju.'],expected:'Około 12,5 V lub więcej zwykle wskazuje na naładowany akumulator; interpretuj wg typu akumulatora.'},
 {title:'Ładowanie — test na pracującym silniku',steps:['Zmierz napięcie na akumulatorze przed uruchomieniem.','Uruchom silnik i wykonaj pomiar na biegu jałowym.','Powtórz przy podwyższonych obrotach.','Włącz światła i ponów pomiar pod obciążeniem.'],expected:'Typowy zakres kontrolny instalacji 12 V to około 13,8–14,6 V, ale sprawdź DTR konkretnego pojazdu.'},
 {title:'Stator — uzwojenia',steps:['Odłącz złącze statora zgodnie z DTR.','Pomiar rezystancji wykonuj na wyłączonym zapłonie.','Porównaj pary przewodów między sobą i z masą.','Jeżeli DTR przewiduje pomiar AC, wykonaj go podczas kręcenia/ pracy silnika.'],expected:'Nie ma jednej uniwersalnej rezystancji — użyj wartości producenta.'},
 {title:'Cewka zapłonowa',steps:['Odłącz cewkę zgodnie z DTR.','Zmierz uzwojenie pierwotne.','Zmierz uzwojenie wtórne zgodnie z instrukcją producenta.','Sprawdź także fajkę, przewód WN i masę.'],expected:'Rezystancje są zależne od konstrukcji; nie oceniaj części tylko po jednej wartości.'},
 {title:'Impulsator / pickup',steps:['Odłącz złącze pickup.','Zmierz rezystancję, jeśli przewiduje ją DTR.','W razie potrzeby zmierz napięcie AC podczas kręcenia.','Sprawdź przewody pod kątem przerwy i zwarcia do masy.'],expected:'Parametry zależą od konkretnego układu CDI/ECU.'},
 {title:'Ciągłość przewodu',steps:['Wyłącz zapłon i odłącz zasilanie badanego obwodu.','Ustaw multimetr na ciągłość/Ω.','Zmierz oba końce przewodu.','Poruszaj wiązką podczas pomiaru, aby wykryć przerywanie.'],expected:'Dla sprawnego przewodu opór powinien być bardzo niski; dokładny próg zależy od długości i połączeń.'},
 {title:'Spadek napięcia — masa',steps:['Uruchom obwód pod obciążeniem.','Ustaw V DC.','Zmierz między minusem akumulatora a obudową badanego odbiornika.','Powtórz podczas rozruchu lub pracy dużego odbiornika.'],expected:'Im mniejszy spadek, tym lepiej. Wysoki spadek wskazuje na problem z masą/połączeniem.'},
];

// ---------- STORAGE ----------
const STORAGE_SCHEMA_VERSION = 8;

const load = async (key, fallback = []) => {
  try { const v = await AsyncStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch (e) { return fallback; }
};
const save = async (key, val) => { try { await AsyncStorage.setItem(key, JSON.stringify(val)); } catch (e) {} };

// ---------- UI HELPERS ----------
const Btn = ({ onPress, children, style }) => (
  <TouchableOpacity style={style} onPress={onPress} activeOpacity={0.84}>
    <LinearGradient colors={['#8a2be2', '#d21cff', '#ff8a00']} start={{x:0,y:0.5}} end={{x:1,y:0.5}} style={s.btnGradient}>
      <Text style={s.btnText}>{children}</Text>
    </LinearGradient>
  </TouchableOpacity>
);
const Card = ({ title, children }) => (
  <View style={s.card}>{title ? <Text style={s.h2}>{title}</Text> : null}{children}</View>
);
const Entry = ({ title, sub, children }) => (
  <View style={s.entry}>{title ? <Text style={s.entryTitle}>{title}</Text> : null}{sub ? <Text style={s.entrySub}>{sub}</Text> : null}{children}</View>
);

const SERVICE_DATA = {
  '2T': {
    fluids:[['Olej przekładniowy','wg DTR / modelu'],['Płyn hamulcowy','wg specyfikacji układu'],['Płyn chłodniczy LC','wg producenta płynu / DTR'],['Olej do mieszanki','zgodny z wymaganiami silnika 2T']],
    intervals:[['Olej przekładniowy','wg DTR / przebiegu'],['Świeca','kontrola okresowa + wymiana wg DTR'],['Filtr powietrza','kontrola/czyszczenie zależnie od warunków'],['Pasek CVT (skuter)','kontrola szerokości i pęknięć'],['Układ hamulcowy','kontrola przed jazdą i okresowo']]
  },
  '4T': {
    fluids:[['Olej silnikowy','lepkość i norma wg DTR'],['Płyn hamulcowy','wg specyfikacji układu'],['Płyn chłodniczy','jeśli LC — wg DTR'],['Olej przekładniowy','jeśli osobny obieg — wg DTR']],
    intervals:[['Olej silnikowy','wg DTR / przebiegu / czasu'],['Filtr oleju','przy wymianie oleju, jeśli występuje'],['Luz zaworowy','wg DTR i warunków pracy'],['Filtr powietrza','kontrola/czyszczenie lub wymiana'],['Napęd łańcuchowy','smarowanie i kontrola luzu']]
  },
  'CVT': {
    fluids:[['Olej przekładni końcowej','wg DTR'],['Olej silnikowy 4T','wg DTR'],['Płyn hamulcowy','wg specyfikacji układu'],['Płyn chłodniczy','jeśli LC — wg DTR']],
    intervals:[['Pasek CVT','kontrola szerokości i stanu'],['Rolki wariatora','kontrola zużycia'],['Sprzęgło','kontrola okładzin i dzwonu'],['Olej przekładni','wg DTR / przebiegu'],['Filtr powietrza','wg warunków i DTR']]
  }
};


export default function App() {
  const [view, setView] = useState('home');
  const [notes, setNotes] = useState([]);
  const [logs, setLogs] = useState([]);
  const [shop, setShop] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [points, setPoints] = useState(0);
  const [diagStack, setDiagStack] = useState([DIAG_TREE]);
  const [diagCrumbs, setDiagCrumbs] = useState(['Diagnostyka']);
  const [diagLeaf, setDiagLeaf] = useState(null);
  const [engineType, setEngineType] = useState('2T');
  const [query, setQuery] = useState('');
  const [noteVin, setNoteVin] = useState(''); const [noteText, setNoteText] = useState('');
  const [logVin, setLogVin] = useState(''); const [logDesc, setLogDesc] = useState('');
  const [submitText, setSubmitText] = useState(''); const [submitName, setSubmitName] = useState('');
  const [mixLiters, setMixLiters] = useState(''); const [mixRatio, setMixRatio] = useState(40);
  const [reminders, setReminders] = useState([]);
  const [remVin, setRemVin] = useState(''); const [remDesc, setRemDesc] = useState(''); const [remDate, setRemDate] = useState('');
  const [checkDone, setCheckDone] = useState([]);
  const [isPro, setIsPro] = useState(false);
  const [vehicles, setVehicles] = useState([]);
  const [repairs, setRepairs] = useState([]);
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);
  const [vehicleForm, setVehicleForm] = useState({ vin:'', brand:'', model:'', year:'', engine:'', engineProfileId:'am6', mileage:'', mods:'', notes:'', customerName:'', customerPhone:'', customerEmail:'' });
  const [repairForm, setRepairForm] = useState({ symptom:'', diagnosis:'', repair:'', parts:'', cost:'', mileage:'', notes:'', labor:'', partsCost:'', margin:'', status:'Nowe' });
  const [diagFlowId, setDiagFlowId] = useState(null);
  const [diagStepId, setDiagStepId] = useState(null);
  const [diagHistory, setDiagHistory] = useState([]);
  const [engineProfileId, setEngineProfileId] = useState('am6');
  const [meterProcedure, setMeterProcedure] = useState(null);
  const [appMode, setAppMode] = useState('workshop');
  const [theme, setTheme] = useState('kameleon');
  const [repairTest, setRepairTest] = useState({before:'', beforeResult:'', after:'', afterResult:'', passed:'', notes:''});
  const [serviceType, setServiceType] = useState('4T');
  const [obdQuery, setObdQuery] = useState('');
  const [healthProfiles, setHealthProfiles] = useState([]);
  const [caseQuery, setCaseQuery] = useState('');
  const [photoUri, setPhotoUri] = useState(null);
  const [photoNote, setPhotoNote] = useState('');
  const [photoCases, setPhotoCases] = useState([]);
  const [sensorRunning, setSensorRunning] = useState(false);
  const [sensorData, setSensorData] = useState({accel:null,gyro:null,light:null});
  const sensorSubs = React.useRef([]);

  useEffect(() => {
    (async () => {
      setNotes(await load('naprawnik_notes'));
      setLogs(await load('naprawnik_log'));
      setShop(await load('naprawnik_shop'));
      setSubmissions(await load('naprawnik_submissions'));
      setPoints((await load('naprawnik_points', [0]))[0] || 0);
      setReminders(await load('naprawnik_reminders'));
      setCheckDone(await load('naprawnik_checklist_done'));
      setIsPro((await load('naprawnik_pro', [false]))[0] || false);
      setVehicles(await load('naprawnik_vehicles'));
      setRepairs(await load('naprawnik_repairs'));
      setDiagHistory(await load('naprawnik_diag_history'));
      setHealthProfiles(await load('naprawnik_health_profiles'));
      setPhotoCases(await load('naprawnik_photo_cases'));
      setAppMode((await load('naprawnik_mode', ['workshop']))[0] || 'workshop');
      setTheme((await load('naprawnik_theme', ['kameleon']))[0] || 'kameleon');
    })();
  }, []);

  useEffect(() => {
    const errors = validateDiagFlows();
    if (errors.length) console.warn('[NAPRAWNIK] Diagnosis Core validation:', errors);
  }, []);

  useEffect(() => {
    if (!vehicles.length) return;
    const link = (items) => items.map(x => {
      if (x.vehicleId || !x.vin) return x;
      const v=vehicles.find(y=>(y.vin||'').trim().toUpperCase()===(x.vin||'').trim().toUpperCase());
      return v ? {...x, vehicleId:v.id} : x;
    });
    const ns=link(notes), ls=link(logs), rs=link(reminders);
    if (JSON.stringify(ns)!==JSON.stringify(notes)) { setNotes(ns); save('naprawnik_notes',ns); }
    if (JSON.stringify(ls)!==JSON.stringify(logs)) { setLogs(ls); save('naprawnik_log',ls); }
    if (JSON.stringify(rs)!==JSON.stringify(reminders)) { setReminders(rs); save('naprawnik_reminders',rs); }
  }, [vehicles]);

  useEffect(() => () => stopSensors(), []);

  const goHome = () => setView('home');
  const changeMode = async (mode) => { setAppMode(mode); await save('naprawnik_mode', [mode]); setView('home'); };
  const changeTheme = async (next) => { setTheme(next); await save('naprawnik_theme', [next]); };
  const themeLabel = theme === 'kameleon' ? 'Fiolet → Magenta → Pomarańcz' : theme === 'purple' ? 'Fioletowy' : 'Pomarańczowy';
  const openDiag = () => { setDiagStack([DIAG_TREE]); setDiagCrumbs(['Diagnostyka']); setDiagLeaf(null); setView('diag'); };
  const diagSelect = (node) => {
    setDiagCrumbs([...diagCrumbs, node.label]);
    if (node.children) setDiagStack([...diagStack, node.children]);
    else setDiagLeaf(node);
  };
  const diagBack = () => {
    if (diagLeaf) { setDiagLeaf(null); setDiagCrumbs(diagCrumbs.slice(0, -1)); return; }
    if (diagStack.length > 1) { setDiagStack(diagStack.slice(0, -1)); setDiagCrumbs(diagCrumbs.slice(0, -1)); }
    else goHome();
  };

  // Jedno źródło prawdy dla limitu Free: kartoteka pojazdów.
  // Stare wpisy z samym VIN-em są automatycznie podpinane do istniejącej kartoteki.
  const checkVehicleLimit = () => {
    if (isPro || vehicles.length < FREE_VIN_LIMIT) return true;
    Alert.alert(
      'Limit wersji Free',
      `W wersji darmowej możesz mieć maks. ${FREE_VIN_LIMIT} kartoteki pojazdów. Dodaj kolejny pojazd po przejściu na PRO.`,
      [{ text: 'Anuluj' }, { text: 'Zobacz PRO', onPress: () => setView('pro') }]
    );
    return false;
  };

  const upgradeToPro = async () => {
    setIsPro(true); await save('naprawnik_pro', [true]);
    Alert.alert('Gotowe!', 'Konto PRO aktywne (tryb testowy — prawdziwe płatności podłączymy po konfiguracji RevenueCat).');
  };
  const downgradeToFree = async () => { setIsPro(false); await save('naprawnik_pro', [false]); };

  const findVehicleByVin = (vin) => {
    const v=(vin||'').trim().toUpperCase();
    if(!v) return null;
    return vehicles.find(x=>(x.vin||'').trim().toUpperCase()===v) || null;
  };
  const requireKnownVehicleForVin = (vin) => {
    const normalized=(vin||'').trim().toUpperCase();
    if(!normalized) return true;
    if(findVehicleByVin(normalized)) return true;
    Alert.alert('Najpierw dodaj pojazd', 'VIN jest używany jako identyfikator historii. Dodaj ten pojazd do Kartoteki pojazdów, a potem zapisz wpis.');
    return false;
  };
  const addNote = async () => {
    if (!noteText.trim()) return;
    if (!requireKnownVehicleForVin(noteVin)) return;
    const vehicle=findVehicleByVin(noteVin);
    const n = [...notes, { id:Date.now().toString(), vehicleId:vehicle?.id||null, vin: noteVin.trim().toUpperCase(), text: noteText.trim(), date: new Date().toLocaleString('pl-PL') }];
    setNotes(n); await save('naprawnik_notes', n); setNoteText(''); setNoteVin('');
  };
  const addLog = async () => {
    if (!logDesc.trim()) return;
    if (!requireKnownVehicleForVin(logVin)) return;
    const vehicle=findVehicleByVin(logVin);
    const l = [...logs, { id:Date.now().toString(), vehicleId:vehicle?.id||null, vin: logVin.trim().toUpperCase(), desc: logDesc.trim(), date: new Date().toLocaleString('pl-PL') }];
    setLogs(l); await save('naprawnik_log', l); setLogDesc(''); setLogVin('');
  };
  const addShop = async (name, tier, price) => {
    const l = [...shop, { name, tier, price }];
    setShop(l); await save('naprawnik_shop', l);
  };
  const clearShop = async () => { setShop([]); await save('naprawnik_shop', []); };

  const toggleCheck = async (i) => {
    const d = checkDone.includes(i) ? checkDone.filter(x => x !== i) : [...checkDone, i];
    setCheckDone(d); await save('naprawnik_checklist_done', d);
  };
  const resetChecklist = async () => { setCheckDone([]); await save('naprawnik_checklist_done', []); };
  const startDiagFlow = (id) => { const f=DIAG_FLOWS[id]; if(!f) return; setDiagFlowId(id); setDiagStepId(null); setView('diagFlow'); setDiagStepId(f.steps[0]?.id || null); };
  const currentDiagStep = () => getDiagStep(diagFlowId, diagStepId);
  const answerDiagFlow = async (answer) => { const f=DIAG_FLOWS[diagFlowId]; const st=currentDiagStep(); if(!f||!st) return; const next=st[answer]; if(!next) return; const n=getDiagStep(diagFlowId,next); if(n?.result){ const h=[...diagHistory,{flow:f.title,result:n.result,detail:n.detail,date:new Date().toLocaleString('pl-PL'),vehicleId:selectedVehicleId}]; setDiagHistory(h); await save('naprawnik_diag_history',h); setDiagStepId(next); } else setDiagStepId(next); };
  const resetDiagFlow = () => { setDiagFlowId(null); setDiagStepId(null); setView('diag'); };
  const addVehicle = async () => {
    const vin=(vehicleForm.vin||'').trim().toUpperCase();
    const v={...vehicleForm,vin,id:Date.now().toString(),createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
    if(!v.brand.trim()&&!v.model.trim()&&!vin){Alert.alert('Brak danych','Podaj przynajmniej VIN, markę lub model.');return;}
    if(vin && vehicles.some(x=>(x.vin||'').trim().toUpperCase()===vin)){Alert.alert('VIN już istnieje','Ten pojazd jest już w kartotece. Otwórz istniejącą kartę zamiast tworzyć duplikat.');return;}
    if(!checkVehicleLimit()) return;
    const a=[...vehicles,v]; setVehicles(a); await save('naprawnik_vehicles',a);
    // Jeżeli wcześniej istniały wpisy z tym VIN-em, od razu spinamy je z nową kartoteką.
    const ns=notes.map(x=>!x.vehicleId&&x.vin===vin?{...x,vehicleId:v.id}:x);
    const ls=logs.map(x=>!x.vehicleId&&x.vin===vin?{...x,vehicleId:v.id}:x);
    const rs=reminders.map(x=>!x.vehicleId&&x.vin===vin?{...x,vehicleId:v.id}:x);
    setNotes(ns); setLogs(ls); setReminders(rs);
    await save('naprawnik_notes',ns); await save('naprawnik_log',ls); await save('naprawnik_reminders',rs);
    setSelectedVehicleId(v.id); setVehicleForm({vin:'',brand:'',model:'',year:'',engine:'',engineProfileId:'am6',mileage:'',mods:'',notes:'',customerName:'',customerPhone:'',customerEmail:''}); setView('vehicleDetail');
  };
  const getHealth = (vehicleId) => healthProfiles.find(x=>x.vehicleId===vehicleId) || {vehicleId,battery:'',charging:'',compression:'',temperature:'',oil:'',obd:'',brakes:'',tyres:'',updatedAt:null};
  const saveHealth = async (vehicleId, patch) => {
    const current=getHealth(vehicleId); const next={...current,...patch,vehicleId,updatedAt:new Date().toISOString()};
    const all=healthProfiles.some(x=>x.vehicleId===vehicleId)?healthProfiles.map(x=>x.vehicleId===vehicleId?next:x):[...healthProfiles,next];
    setHealthProfiles(all); await save('naprawnik_health_profiles',all); return next;
  };
  const stopSensors = () => { sensorSubs.current.forEach(x=>x&&x.remove&&x.remove()); sensorSubs.current=[]; setSensorRunning(false); };
  const startSensors = () => {
    stopSensors();
    try {
      Accelerometer.setUpdateInterval(250); Gyroscope.setUpdateInterval(250);
      sensorSubs.current.push(Accelerometer.addListener(v=>setSensorData(x=>({...x,accel:v}))));
      sensorSubs.current.push(Gyroscope.addListener(v=>setSensorData(x=>({...x,gyro:v}))));
      if(LightSensor && LightSensor.addListener){ LightSensor.setUpdateInterval(500); sensorSubs.current.push(LightSensor.addListener(v=>setSensorData(x=>({...x,light:v})))); }
      setSensorRunning(true);
    } catch(e) { Alert.alert('Sensor Hub','Telefon nie udostępnił któregoś z sensorów.'); }
  };
  const savePhotoCase = async () => {
    if(!photoUri) return;
    const item={id:Date.now().toString(),vehicleId:selectedVehicleId,uri:photoUri,note:photoNote.trim(),date:new Date().toLocaleString('pl-PL'),analysis:photoNote.trim()?['Analiza wspomagana: opis użytkownika został zapisany jako obserwacja.','Porównaj zdjęcie z objawem i potwierdź hipotezę pomiarem.']:['Brak opisu — dodaj obserwację, aby uzyskać trafniejsze wskazówki.']};
    const all=[...photoCases,item]; setPhotoCases(all); await save('naprawnik_photo_cases',all); setPhotoNote(''); setPhotoUri(''); Alert.alert('Zapisano','Zdjęcie dodano do historii pojazdu.');
  };
  const pickPhoto = async (camera=false) => {
    const perm=camera?await ImagePicker.requestCameraPermissionsAsync():await ImagePicker.requestMediaLibraryPermissionsAsync();
    if(!perm.granted){Alert.alert('Brak uprawnień','Zezwól aplikacji na dostęp do aparatu/zdjęć.');return;}
    const r=camera?await ImagePicker.launchCameraAsync({quality:.7,allowsEditing:true}):await ImagePicker.launchImageLibraryAsync({mediaTypes:['images'],quality:.7,allowsEditing:true});
    if(!r.canceled) setPhotoUri(r.assets[0].uri);
  };
  const buildCustomerReport = (v) => {
    const rs=repairs.filter(r=>r.vehicleId===v.id).slice().reverse(); const h=getHealth(v.id);
    const total=rs.reduce((a,r)=>a+(parseFloat(r.cost)||((parseFloat(r.labor)||0)+(parseFloat(r.partsCost)||0)),0);
    return `NAPRAWNIK — RAPORT DLA KLIENTA\n\nPojazd: ${v.brand||''} ${v.model||''}\nVIN: ${v.vin||'—'}\nRok: ${v.year||'—'}\nPrzebieg: ${v.mileage||'—'}\nKlient: ${v.customerName||'—'}\nTelefon: ${v.customerPhone||'—'}\n\nSTAN POJAZDU\nAkumulator: ${h.battery||'—'}\nŁadowanie: ${h.charging||'—'}\nKompresja: ${h.compression||'—'}\nTemperatura: ${h.temperature||'—'}\nHamulce: ${h.brakes||'—'}\nOpony: ${h.tyres||'—'}\nOBD: ${h.obd||'—'}\n\nWYKONANE PRACE\n${rs.length?rs.map(r=>`• ${r.repair} | koszt ${r.cost||(((parseFloat(r.labor)||0)+(parseFloat(r.partsCost)||0)).toFixed(2))} zł | robocizna ${r.labor||'—'} | części ${r.partsCost||'—'} | ${r.status||'—'}`).join('\n'):'Brak wpisów'}\n\nŁączny koszt zapisanych prac: ${total.toFixed(2)} zł\n\nRaport wygenerowany przez NAPRAWNIK.`;
  };
  const shareCustomerReport = async (v) => { try { await Share.share({message:buildCustomerReport(v),title:'Raport NAPRAWNIK'}); } catch(e) {} };

  const addRepair = async () => {
    if(!selectedVehicleId||!repairForm.repair.trim()){Alert.alert('Brak danych','Wpisz opis wykonanej naprawy.');return;}
    const r={...repairForm,id:Date.now().toString(),vehicleId:selectedVehicleId,date:new Date().toLocaleString('pl-PL'),createdAt:new Date().toISOString(),testBefore:repairTest.beforeResult||'',testAfter:repairTest.afterResult||'',testPassed:repairTest.passed||'',testNotes:repairTest.notes||'',testBeforeQuestion:repairTest.before||'',testAfterQuestion:repairTest.after||''};
    const a=[...repairs,r]; setRepairs(a); await save('naprawnik_repairs',a);
    setRepairForm({symptom:'',diagnosis:'',repair:'',parts:'',cost:'',mileage:'',notes:'',labor:'',partsCost:'',margin:'',status:'Nowe'}); setRepairTest({before:'',beforeResult:'',after:'',afterResult:'',passed:'',notes:''});
    Alert.alert('Zapisano','Naprawa i test przed/po zostały dodane do historii pojazdu.');
  };
  const deleteVehicle = async (id) => { const vs=vehicles.filter(v=>v.id!==id), rs=repairs.filter(r=>r.vehicleId!==id), ns=notes.filter(x=>x.vehicleId!==id), ls=logs.filter(x=>x.vehicleId!==id), rr=reminders.filter(x=>x.vehicleId!==id), dh=diagHistory.filter(x=>x.vehicleId!==id); setVehicles(vs); setRepairs(rs); setNotes(ns); setLogs(ls); setReminders(rr); setDiagHistory(dh); await save('naprawnik_vehicles',vs); await save('naprawnik_repairs',rs); await save('naprawnik_notes',ns); await save('naprawnik_log',ls); await save('naprawnik_reminders',rr); await save('naprawnik_diag_history',dh); setSelectedVehicleId(null); setView('vehicles'); };
  const exportData = async () => {
    const payload = { appVersion: 'NAPRAWNIK V2 Kameleon Stage 7.1', schemaVersion: STORAGE_SCHEMA_VERSION, diagnosisCore: 'v2', notes, logs, shop, reminders, submissions, points, vehicles, repairs, diagHistory, healthProfiles, photoCases, exportDate: new Date().toISOString() };
    try {
      await Share.share({ message: JSON.stringify(payload, null, 2), title: 'Naprawnik — backup danych' });
    } catch (e) { Alert.alert('Błąd', 'Nie udało się wyeksportować danych.'); }
  };

  // ---------- WIDOKI ----------
  const renderHome = () => (
    <ScrollView>
      <LinearGradient colors={['#1a0830', '#100914', '#35120a']} start={{x:0,y:0}} end={{x:1,y:1}} style={s.hero}>
        <View style={s.heroRow}>
          <View style={s.heroLogo}><Text style={s.heroLogoText}>🦎</Text></View>
          <View style={{flex:1}}>
            <Text style={s.heroBrand}>NAPRAWNIK</Text>
            <Text style={s.heroKameleon}>KAMELEON</Text>
          </View>
          <TouchableOpacity style={s.modePill} onPress={()=>setView('settings')}><Text style={s.modePillText}>{appMode==='workshop'?'WARSZTAT':'AMATOR'}</Text></TouchableOpacity>
        </View>
        <Text style={s.heroSub}>{appMode==='workshop'?'Twoje narzędzie w warsztacie':'Twój mobilny asystent mechanika'}</Text>
        <Text style={s.heroPowered}>Powered by TurboDiesel · {themeLabel}</Text>
      </LinearGradient>
      <Card title={appMode==='workshop'?'TRYB WARSZTATOWY':'TRYB WŁAŚCICIELA'}>
        <Text style={s.entryBody}>{appMode==='workshop'?'Diagnoza → test → naprawa → historia. Wszystko przypięte do pojazdu.':'Szybka diagnoza, historia pojazdu, przypomnienia i podstawowe procedury.'}</Text>
      </Card>
      <View style={s.grid2}>
        <Tile icon="🔧" label="Diagnostyka" onPress={openDiag} />
        <Tile icon="🧪" label="Diagnoza krok po kroku" onPress={() => setView('diagFlow')} />
        <Tile icon="🏍️" label="Kartoteka pojazdów" onPress={() => setView('vehicles')} />
        <Tile icon="⚡" label="Elektryka" onPress={() => setView('electric')} />
        <Tile icon="📐" label="Momenty / silniki" onPress={() => setView('models')} />
        <Tile icon="🧮" label="Kalkulatory 2T" onPress={() => setView('mix')} />
        <Tile icon="🧴" label="Płyny i serwis" onPress={() => setView('service')} />
        <Tile icon="🧾" label="OBD / P0xxx" onPress={() => setView('obd')} />
        {appMode==='workshop' && <>
          <Tile icon="🛠️" label="Warsztat" onPress={() => setView('vehicles')} />
          <Tile icon="📝" label="Czarna Skrzynka" onPress={() => setView('log')} />
        </>}
        {appMode==='owner' && <>
          <Tile icon="⏰" label="Przypomnienia" onPress={() => setView('reminders')} />
          <Tile icon="✅" label="Checklista" onPress={() => setView('checklist')} />
        </>}
      </View>
      <Btn onPress={() => setView('vehicles')}>🏍️ Otwórz kartotekę pojazdów</Btn>
      <Btn onPress={() => setView('electricalHub')}>🔌 Baza instalacji 50–250 cc</Btn>
      <Btn onPress={() => setView('multimeter')}>📏 Procedury multimetru</Btn>
      <Btn onPress={() => setView('obd')}>🧾 Słownik OBD / P0xxx</Btn>
      {appMode==='workshop' && <Btn onPress={() => setView('shop')}>💰 Cennik / lista części</Btn>}
      <Btn onPress={() => setView('settings')}>⚙️ Ustawienia Kameleona</Btn>
    </ScrollView>
  );

  const Tile = ({ icon, label, onPress }) => (
    <TouchableOpacity style={s.tile} onPress={onPress}>
      <Text style={s.tileIcon}>{icon}</Text><Text style={s.tileLabel}>{label}</Text>
    </TouchableOpacity>
  );
  const BackBtn = ({ onPress }) => (
    <TouchableOpacity onPress={onPress}><Text style={s.backBtn}>← Wstecz</Text></TouchableOpacity>
  );
  const Crumbs = ({ items }) => <Text style={s.crumbs}>{items.join(' › ')}</Text>;


  const renderDiag = () => {
    if (diagLeaf) {
      return (
        <ScrollView>
          <BackBtn onPress={diagBack} /><Crumbs items={diagCrumbs} />
          <Card title="Prawdopodobne przyczyny">
            {diagLeaf.causes.map((c, i) => <Entry key={i} sub={`• ${c}`} />)}
          </Card>
          <Btn onPress={openDiag}>🔁 Zacznij od nowa</Btn>
          <Btn onPress={() => setView('submit')}>💡 Zaproponuj inną przyczynę</Btn>
        </ScrollView>
      );
    }
    const level = diagStack[diagStack.length - 1];
    return (
      <ScrollView>
        <BackBtn onPress={diagBack} /><Crumbs items={diagCrumbs} />
        {level.map((n, i) => <Btn key={i} onPress={() => diagSelect(n)}>{n.label} →</Btn>)}
      </ScrollView>
    );
  };

  const typeName = (t) => (t === '2T' ? 'Dwusuw 2T' : t === '4T' ? 'Czterosuw 4T' : 'CVT (Skutery)');

  const renderDiagFlow = () => { const f=DIAG_FLOWS[diagFlowId]; const st=currentDiagStep(); if(!f||!st) return <ScrollView><BackBtn onPress={resetDiagFlow}/><Card title="Diagnostyka krok po kroku">{Object.entries(DIAG_FLOWS).map(([id,x])=><Btn key={id} onPress={()=>startDiagFlow(id)}>{x.title} →</Btn>)}</Card></ScrollView>; if(st.result) return <ScrollView><BackBtn onPress={resetDiagFlow}/><Card title="Wynik diagnozy"><Text style={s.result}>{st.result}</Text><Text style={s.entryBody}>{st.detail}</Text><Text style={s.dimSmall}>Wynik jest wskazówką diagnostyczną, nie potwierdzeniem uszkodzenia części.</Text></Card><Btn onPress={()=>setView(selectedVehicleId?'vehicleDetail':'vehicles')}>🧾 Zapisz / przejdź do historii</Btn><Btn onPress={resetDiagFlow}>🔁 Nowa diagnoza</Btn></ScrollView>; return <ScrollView><BackBtn onPress={resetDiagFlow}/><Card title={f.title}>{selectedVehicleId ? <Text style={s.dim}>Pojazd: {(vehicles.find(v=>v.id===selectedVehicleId)?.brand||'')} {(vehicles.find(v=>v.id===selectedVehicleId)?.model||'')} · VIN: {vehicles.find(v=>v.id===selectedVehicleId)?.vin||'—'}</Text> : <><Text style={s.dim}>Przypnij wynik do kartoteki, jeśli chcesz zachować diagnozę w historii pojazdu:</Text>{vehicles.slice(0,FREE_VIN_LIMIT).map(v=><TouchableOpacity key={v.id} style={s.profileChip} onPress={()=>setSelectedVehicleId(v.id)}><Text style={s.profileChipText}>{v.brand||'Pojazd'} {v.model||''} · {v.vin||'bez VIN'}</Text></TouchableOpacity>)}<Text style={s.dimSmall}>Możesz też kontynuować bez przypisania.</Text></>}<Text style={s.h2}>{st.q}</Text>{st.expected&&<Text style={s.dim}>Kontrola: {st.expected}</Text>}{st.warn&&<Text style={s.warning}>⚠️ {st.warn}</Text>}<Btn onPress={()=>answerDiagFlow('yes')}>TAK / wynik prawidłowy</Btn><Btn onPress={()=>answerDiagFlow('no')}>NIE / wynik nieprawidłowy</Btn><Btn onPress={()=>setDiagStepId(f.steps.find(x=>x.result)?.id || 0)}>Nie wiem — zakończ test</Btn></Card></ScrollView>; };

  const renderVehicles = () => <ScrollView><BackBtn onPress={goHome}/><Card title={`Kartoteka pojazdów · ${vehicles.length}`}>
    <TextInput style={s.input} placeholder="VIN" placeholderTextColor="#666" value={vehicleForm.vin} onChangeText={v=>setVehicleForm({...vehicleForm,vin:v})}/>
    <View style={s.grid2}><TextInput style={[s.input,{width:'48%'}]} placeholder="Marka" placeholderTextColor="#666" value={vehicleForm.brand} onChangeText={v=>setVehicleForm({...vehicleForm,brand:v})}/><TextInput style={[s.input,{width:'48%'}]} placeholder="Model" placeholderTextColor="#666" value={vehicleForm.model} onChangeText={v=>setVehicleForm({...vehicleForm,model:v})}/></View>
    <View style={s.grid2}><TextInput style={[s.input,{width:'48%'}]} placeholder="Rok" placeholderTextColor="#666" value={vehicleForm.year} onChangeText={v=>setVehicleForm({...vehicleForm,year:v})}/><TextInput style={[s.input,{width:'48%'}]} placeholder="Przebieg" placeholderTextColor="#666" value={vehicleForm.mileage} onChangeText={v=>setVehicleForm({...vehicleForm,mileage:v})}/></View>
    <Text style={s.dim}>Profil silnika — później zasili diagnostykę, momenty i checklisty:</Text>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:8}}>{ENGINE_PROFILES.map(p=><TouchableOpacity key={p.id} onPress={()=>setVehicleForm({...vehicleForm,engineProfileId:p.id,engine:p.name})} style={vehicleForm.engineProfileId===p.id?s.profileChipActive:s.profileChip}><Text style={s.profileChipText}>{p.name}</Text></TouchableOpacity>)}</ScrollView>
    <TextInput style={s.input} placeholder="Klient — imię i nazwisko (opcjonalnie)" placeholderTextColor="#666" value={vehicleForm.customerName||''} onChangeText={v=>setVehicleForm({...vehicleForm,customerName:v})}/>
    <TextInput style={s.input} placeholder="Telefon klienta (opcjonalnie)" placeholderTextColor="#666" keyboardType="phone-pad" value={vehicleForm.customerPhone||''} onChangeText={v=>setVehicleForm({...vehicleForm,customerPhone:v})}/>
    <TextInput style={s.input} placeholder="E-mail klienta (opcjonalnie)" placeholderTextColor="#666" keyboardType="email-address" value={vehicleForm.customerEmail||''} onChangeText={v=>setVehicleForm({...vehicleForm,customerEmail:v})}/>
    <TextInput style={[s.input,s.textarea]} placeholder="Modyfikacje / uwagi" placeholderTextColor="#666" value={vehicleForm.mods} onChangeText={v=>setVehicleForm({...vehicleForm,mods:v})} multiline/>
    <Btn onPress={addVehicle}>＋ Dodaj pojazd</Btn>
    <Text style={s.dimSmall}>Free: {vehicles.length}/{FREE_VIN_LIMIT} kartotek · PRO: bez limitu</Text>
  </Card>
  {vehicles.length===0?<Text style={s.empty}>Brak pojazdów. Utwórz pierwszą kartotekę.</Text>:vehicles.map(v=><TouchableOpacity key={v.id} style={s.entry} onPress={()=>{setSelectedVehicleId(v.id);setView('vehicleDetail')}}><Text style={s.entryTitle}>{v.brand||'Pojazd'} {v.model||''}</Text><Text style={s.entrySub}>{v.vin||'Bez VIN'} · {v.year||'rok —'} · {v.engine||'silnik —'}</Text><Text style={s.dimSmall}>{v.engineProfileId?ENGINE_PROFILES.find(p=>p.id===v.engineProfileId)?.family||'Profil': 'Profil nieustawiony'}</Text></TouchableOpacity>)}</ScrollView>;

  const renderVehicleDetail = () => {
    const v=vehicles.find(x=>x.id===selectedVehicleId); if(!v)return <ScrollView><Btn onPress={()=>setView('vehicles')}>Wróć</Btn></ScrollView>;
    const rs=repairs.filter(x=>x.vehicleId===selectedVehicleId);
    const vhNotes=notes.filter(x=>x.vehicleId===selectedVehicleId || (!x.vehicleId && x.vin && x.vin===v.vin));
    const vhLogs=logs.filter(x=>x.vehicleId===selectedVehicleId || (!x.vehicleId && x.vin && x.vin===v.vin));
    const vhRem=reminders.filter(x=>x.vehicleId===selectedVehicleId || (!x.vehicleId && x.vin && x.vin===v.vin));
    const hp=getHealth(v.id);
    const diary=[...diagHistory.filter(x=>x.vehicleId===v.id).map(x=>({...x,type:'Diagnoza',when:x.date,title:x.result,body:x.detail})),...repairs.filter(x=>x.vehicleId===v.id).map(x=>({...x,type:'Naprawa',when:x.date,title:x.repair,body:x.diagnosis})),...photoCases.filter(x=>x.vehicleId===v.id).map(x=>({...x,type:'Zdjęcie',when:x.date,title:'Dokumentacja zdjęciowa',body:x.note}))].sort((a,b)=>String(b.when).localeCompare(String(a.when)));
    const similar=(caseQuery.trim()?repairs.filter(x=>`${x.symptom} ${x.diagnosis} ${x.repair}`.toLowerCase().includes(caseQuery.trim().toLowerCase())):repairs).slice().reverse().slice(0,8);
    return <ScrollView><BackBtn onPress={()=>setView('vehicles')}/>
      <Card title="Profil zdrowia pojazdu">
        <Text style={s.dimSmall}>Stan orientacyjny — wartości wpisuj po realnym pomiarze/testach.</Text>
        {[["battery","Akumulator"],["charging","Ładowanie"],["compression","Kompresja"],["temperature","Temperatura"],["oil","Ciśnienie/jakość oleju"],["obd","OBD"],["brakes","Hamulce"],["tyres","Opony"]].map(([k,l])=><View key={k}><Text style={s.dimSmall}>{l}</Text><TextInput style={s.input} placeholder="np. OK / pomiar / uwaga" placeholderTextColor="#666" value={hp[k]||''} onChangeText={x=>saveHealth(v.id,{[k]:x})}/></View>)}
      </Card>
      <Card title="Klient / zlecenie">
        <TextInput style={s.input} placeholder="Imię i nazwisko klienta" placeholderTextColor="#666" value={v.customerName||''} onChangeText={x=>{const nv=vehicles.map(z=>z.id===v.id?{...z,customerName:x,updatedAt:new Date().toISOString()}:z);setVehicles(nv);save('naprawnik_vehicles',nv)}}/>
        <TextInput style={s.input} placeholder="Telefon" placeholderTextColor="#666" keyboardType="phone-pad" value={v.customerPhone||''} onChangeText={x=>{const nv=vehicles.map(z=>z.id===v.id?{...z,customerPhone:x,updatedAt:new Date().toISOString()}:z);setVehicles(nv);save('naprawnik_vehicles',nv)}}/>
        <TextInput style={s.input} placeholder="E-mail" placeholderTextColor="#666" keyboardType="email-address" value={v.customerEmail||''} onChangeText={x=>{const nv=vehicles.map(z=>z.id===v.id?{...z,customerEmail:x,updatedAt:new Date().toISOString()}:z);setVehicles(nv);save('naprawnik_vehicles',nv)}}/>
        <Btn onPress={()=>shareCustomerReport(v)}>📄 Udostępnij raport dla klienta</Btn>
      </Card>
      <Card title="Dziennik pojazdu">{diary.length?diary.map((d,i)=><Entry key={i} title={`${d.type} · ${d.title||''}`} sub={d.when}><Text style={s.entryBody}>{d.body||''}</Text></Entry>):<Text style={s.empty}>Brak zdarzeń.</Text>}</Card>
      <Card title="Uczenie na podstawie przypadków"><TextInput style={s.input} placeholder="Objaw/słowo, np. gaśnie na gorącym" placeholderTextColor="#666" value={caseQuery} onChangeText={setCaseQuery}/>{similar.length?similar.map((r,i)=><Entry key={i} title={r.repair||'Naprawa'} sub={`${r.symptom||'bez objawu'} · ${r.date}`}><Text style={s.entryBody}>{r.diagnosis||'brak diagnozy'}</Text></Entry>):<Text style={s.empty}>Brak podobnych przypadków.</Text>}</Card>
      <Card title="Sensor Hub"><Text style={s.dim}>Sensor telefonu służy do obserwacji ruchu/położenia. Nie traktuj go jako miernika obrotów, temperatury silnika ani napięcia elektrycznego.</Text><Btn onPress={sensorRunning?stopSensors:startSensors}>{sensorRunning?'⏹ Zatrzymaj sensory':'📡 Uruchom Sensor Hub'}</Btn><Text style={s.entryBody}>ACC: {sensorData.accel?`${sensorData.accel.x.toFixed(2)} / ${sensorData.accel.y.toFixed(2)} / ${sensorData.accel.z.toFixed(2)}`:'—'}{`\n`}GYRO: {sensorData.gyro?`${sensorData.gyro.x.toFixed(2)} / ${sensorData.gyro.y.toFixed(2)} / ${sensorData.gyro.z.toFixed(2)}`:'—'}{`\n`}Światło: {sensorData.light?.illuminance!=null?sensorData.light.illuminance.toFixed(0):'—'}</Text></Card>
      <Card title="Zdjęcia / analiza wspomagana"><Text style={s.dim}>Zdjęcie dokumentuje stan. Analiza w tej wersji nie udaje automatycznej ekspertyzy — wynik trzeba potwierdzić testem.</Text><View style={s.grid2}><Btn onPress={()=>pickPhoto(true)} style={{width:'48%'}}>📷 Aparat</Btn><Btn onPress={()=>pickPhoto(false)} style={{width:'48%'}}>🖼️ Galeria</Btn></View>{photoUri&&<><Image source={{uri:photoUri}} style={{width:'100%',height:220,borderRadius:16,marginBottom:10}} resizeMode="cover"/><Text style={s.dimSmall}>Zdjęcie gotowe do zapisania w dokumentacji.</Text></>}<TextInput style={[s.input,s.textarea]} placeholder="Co widzisz? np. wyciek, pęknięcie, zużycie" placeholderTextColor="#666" value={photoNote} onChangeText={setPhotoNote} multiline/><Btn onPress={savePhotoCase}>+ Zapisz dokumentację</Btn>{photoCases.filter(x=>x.vehicleId===v.id).slice().reverse().map((x,i)=><Entry key={i} title="Zdjęcie" sub={x.date}><Text style={s.entryBody}>{x.note||'bez opisu'}</Text></Entry>)}</Card>
      
      <Card title={`${v.brand||''} ${v.model||'Pojazd'}`}>
        <Text style={s.entrySub}>VIN: {v.vin||'—'}</Text><Text style={s.entrySub}>Rok: {v.year||'—'} · Silnik: {v.engine||'—'} · Przebieg: {v.mileage||'—'}</Text>
        <Text style={s.dimSmall}>Profil: {v.engineProfileId ? (ENGINE_PROFILES.find(p=>p.id===v.engineProfileId)?.name || '—') : 'nieustawiony'}</Text>
        <Text style={s.entryBody}>{v.mods||'Brak modyfikacji / uwag.'}</Text>
        <View style={s.grid2}><Tile icon="🧪" label="Diagnozuj" onPress={()=>setView('diagFlow')}/><Tile icon="📝" label="Notatka" onPress={()=>{setNoteVin(v.vin||'');setView('notes')}}/><Tile icon="🛡️" label="Czarna skrzynka" onPress={()=>{setLogVin(v.vin||'');setView('log')}}/><Tile icon="⏰" label="Przypomnienie" onPress={()=>{setRemVin(v.vin||'');setView('reminders')}}/></View>
      </Card>
      <Card title="Profil stanu pojazdu">
        <Text style={s.entryBody}>Diagnozy: {diagHistory.filter(d=>d.vehicleId===selectedVehicleId).length} · Naprawy: {rs.length}</Text>
        <Text style={s.entryBody}>Przypomnienia: {vhRem.length} · Notatki: {vhNotes.length} · Operacje: {vhLogs.length}</Text>
        <Text style={s.dimSmall}>{rs.length ? `Ostatnia naprawa: ${rs.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)))[0].repair}` : 'Brak zapisanej naprawy.'}</Text>
        {rs.length ? <Text style={s.dimSmall}>Potwierdzone testem po naprawie: {rs.filter(r=>r.testPassed==='TAK').length}/{rs.length}</Text> : null}
        <Text style={s.dimSmall}>Profil stanu jest podsumowaniem historii zapisanej w aplikacji, a nie oceną techniczną pojazdu.</Text>
      </Card>
      <Card title="Historia tego pojazdu">
        <Text style={s.dim}>Diagnozy: {diagHistory.filter(d=>d.vehicleId===selectedVehicleId).length} · Naprawy: {rs.length} · Notatki: {vhNotes.length} · Operacje: {vhLogs.length} · Przypomnienia: {vhRem.length}</Text>
        {[...vhLogs.map(x=>({date:x.date,title:'Czarna Skrzynka',body:x.desc})),...vhNotes.map(x=>({date:x.date,title:'Notatka',body:x.text})),...vhRem.map(x=>({date:x.date,title:'Przypomnienie',body:x.desc}))].slice(-12).reverse().map((x,i)=><Entry key={i} title={x.title} sub={x.date}><Text style={s.entryBody}>{x.body}</Text></Entry>)}
      </Card>
      <Card title={`Historia diagnostyki (${diagHistory.filter(d=>d.vehicleId===selectedVehicleId).length})`}>
        {diagHistory.filter(d=>d.vehicleId===selectedVehicleId).length?diagHistory.filter(d=>d.vehicleId===selectedVehicleId).slice().reverse().map((d,i)=><Entry key={i} title={d.result} sub={d.date}><Text style={s.entryBody}>{d.flow}{d.detail?`\n${d.detail}`:''}</Text></Entry>):<Text style={s.empty}>Brak zapisanych diagnoz tego pojazdu.</Text>}
      </Card>
      <Card title="Dodaj naprawę">
        <TextInput style={s.input} placeholder="Objaw" placeholderTextColor="#666" value={repairForm.symptom} onChangeText={x=>setRepairForm({...repairForm,symptom:x})}/>
        <TextInput style={s.input} placeholder="Diagnoza" placeholderTextColor="#666" value={repairForm.diagnosis} onChangeText={x=>setRepairForm({...repairForm,diagnosis:x})}/>
        <TextInput style={[s.input,s.textarea]} placeholder="Wykonana naprawa" placeholderTextColor="#666" value={repairForm.repair} onChangeText={x=>setRepairForm({...repairForm,repair:x})} multiline/>
        <TextInput style={s.input} placeholder="Części użyte" placeholderTextColor="#666" value={repairForm.parts} onChangeText={x=>setRepairForm({...repairForm,parts:x})}/>
        <TextInput style={s.input} placeholder="Koszt (zł)" placeholderTextColor="#666" keyboardType="decimal-pad" value={repairForm.cost} onChangeText={x=>setRepairForm({...repairForm,cost:x})}/>
        <TextInput style={s.input} placeholder="Robocizna (zł)" placeholderTextColor="#666" keyboardType="decimal-pad" value={repairForm.labor} onChangeText={x=>setRepairForm({...repairForm,labor:x})}/>
        <TextInput style={s.input} placeholder="Koszt części (zł)" placeholderTextColor="#666" keyboardType="decimal-pad" value={repairForm.partsCost} onChangeText={x=>setRepairForm({...repairForm,partsCost:x})}/>
        <TextInput style={s.input} placeholder="Marża (%) — opcjonalnie" placeholderTextColor="#666" keyboardType="decimal-pad" value={repairForm.margin} onChangeText={x=>setRepairForm({...repairForm,margin:x})}/>
        <TextInput style={s.input} placeholder="Status: Nowe / W toku / Gotowe / Odebrane" placeholderTextColor="#666" value={repairForm.status} onChangeText={x=>setRepairForm({...repairForm,status:x})}/>

        <TextInput style={s.input} placeholder="Przebieg przy naprawie" placeholderTextColor="#666" keyboardType="numeric" value={repairForm.mileage} onChangeText={x=>setRepairForm({...repairForm,mileage:x})}/>
        <Text style={s.h2}>TEST PRZED / PO NAPRAWIE</Text>
        <TextInput style={s.input} placeholder="Co sprawdzamy przed naprawą?" placeholderTextColor="#666" value={repairTest.before} onChangeText={x=>setRepairTest({...repairTest,before:x})}/>
        <TextInput style={[s.input,s.textarea]} placeholder="Wynik przed naprawą" placeholderTextColor="#666" value={repairTest.beforeResult} onChangeText={x=>setRepairTest({...repairTest,beforeResult:x})} multiline/>
        <TextInput style={s.input} placeholder="Co sprawdzamy po naprawie?" placeholderTextColor="#666" value={repairTest.after} onChangeText={x=>setRepairTest({...repairTest,after:x})}/>
        <TextInput style={[s.input,s.textarea]} placeholder="Wynik po naprawie" placeholderTextColor="#666" value={repairTest.afterResult} onChangeText={x=>setRepairTest({...repairTest,afterResult:x})} multiline/>
        <View style={s.grid2}><Btn onPress={()=>setRepairTest({...repairTest,passed:'TAK'})} style={{width:'48%'}}>✓ NAPRAWA POTWIERDZONA</Btn><Btn onPress={()=>setRepairTest({...repairTest,passed:'NIE'})} style={{width:'48%'}}>✕ NIE POTWIERDZONA</Btn></View>
        <TextInput style={[s.input,s.textarea]} placeholder="Uwagi po teście" placeholderTextColor="#666" value={repairTest.notes} onChangeText={x=>setRepairTest({...repairTest,notes:x})} multiline/>
        <Btn onPress={addRepair}>+ Zapisz naprawę i test</Btn>
      </Card>
      <Card title={`Historia napraw (${rs.length})`}>
        {rs.length?rs.slice().reverse().map(r=><Entry key={r.id} title={r.repair} sub={`${r.date} · ${r.cost||'koszt —'}`}><Text style={s.entryBody}>Objaw: {r.symptom||'—'}{r.diagnosis?`\nDiagnoza: ${r.diagnosis}`:''}{r.parts?`\nCzęści: ${r.parts}`:''}{r.mileage?`\nPrzebieg: ${r.mileage}`:''}{r.testBeforeQuestion?`\nTest przed: ${r.testBeforeQuestion}`:''}{r.testBefore?`\nWynik przed: ${r.testBefore}`:''}{r.testAfterQuestion?`\nTest po: ${r.testAfterQuestion}`:''}{r.testAfter?`\nWynik po: ${r.testAfter}`:''}{r.testPassed?`\nPotwierdzenie: ${r.testPassed}`:''}{r.testNotes?`\nUwagi z testu: ${r.testNotes}`:''}{r.notes?`\nUwagi naprawy: ${r.notes}`:''}</Text></Entry>):<Text style={s.empty}>Brak napraw</Text>}
      </Card>
      <Btn onPress={()=>Alert.alert('Usuń pojazd','Usunąć kartotekę i historię napraw?',[{text:'Anuluj'},{text:'Usuń',onPress:()=>deleteVehicle(v.id)}])}>🗑️ Usuń pojazd</Btn>
    </ScrollView>;
  };

  const renderModels = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title="Profile silników / jednostek">
        <Text style={s.dim}>Parametry momentów są orientacyjne. Dla konkretnego modelu zawsze sprawdź DTR producenta.</Text>
        {ENGINE_PROFILES.map(p => <Btn key={p.id} onPress={()=>{setEngineProfileId(p.id);setView('engineProfile')}}>{p.name} · {p.family}</Btn>)}
      </Card>
    </ScrollView>
  );

  const renderEngineProfile = () => {
    const p = ENGINE_PROFILES.find(x=>x.id===engineProfileId) || ENGINE_PROFILES[0];
    return <ScrollView><BackBtn onPress={()=>setView('models')}/><Card title={p.name}><Text style={s.entrySub}>{p.family}</Text><Text style={s.entryBody}>{p.info}</Text></Card><Card title="Kontrola / diagnostyka">{p.checks.map((x,i)=><Entry key={i} sub={`• ${x}`}/>)}</Card><Card title="Momenty orientacyjne">{p.torque.map(([a,b],i)=><View key={i} style={s.tableRow}><Text style={s.tableCell}>{a}</Text><Text style={s.tableCellRight}>{b}</Text></View>)}</Card><Text style={s.dim}>⚠️ Wartości orientacyjne. Wersja silnika, rocznik i producent pojazdu mogą zmieniać specyfikację.</Text></ScrollView>;
  };

  const renderMultimeter = () => {
    const p = meterProcedure ? MULTIMETER_PROCEDURES.find(x=>x.title===meterProcedure) : null;
    if (p) return <ScrollView><BackBtn onPress={()=>setMeterProcedure(null)}/><Card title={p.title}><Text style={s.warning}>⚠️ Odłącz zasilanie tam, gdzie wymaga tego procedura. Nie mierz rezystancji w obwodzie pod napięciem.</Text>{p.steps.map((x,i)=><Entry key={i} title={`${i+1}. ${x}`}/>)}</Card><Card title="Wynik / interpretacja"><Text style={s.entryBody}>{p.expected}</Text></Card></ScrollView>;
    return <ScrollView><BackBtn onPress={goHome}/><Card title="Multimetr — procedury warsztatowe"><Text style={s.dim}>Dobieraj zakres i sposób pomiaru do DTR konkretnego pojazdu.</Text>{MULTIMETER_PROCEDURES.map((x,i)=><Btn key={i} onPress={()=>setMeterProcedure(x.title)}>{x.title}</Btn>)}</Card></ScrollView>;
  };

  const renderEngine = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title={typeName(engineType)}>
        <Btn onPress={() => setView('torque')}>📐 Momenty dokręcania</Btn>
        <Btn onPress={() => setView('wiring')}>⚡ Instalacja elektryczna</Btn>
      </Card>
    </ScrollView>
  );

  const renderTorque = () => (
    <ScrollView>
      <BackBtn onPress={() => setView('engine')} />
      <Card title={`Momenty dokręcania — ${typeName(engineType)}`}>
        {TORQUE[engineType].map(([p, n], i) => (
          <View key={i} style={s.tableRow}><Text style={s.tableCell}>{p}</Text><Text style={s.tableCellRight}>{n} Nm</Text></View>
        ))}
      </Card>
      <Text style={s.dim}>Wartości orientacyjne — zawsze zweryfikuj z DTR producenta.</Text>
    </ScrollView>
  );

  const renderWiring = () => {
    const w = WIRING[engineType];
    return (
      <ScrollView>
        <BackBtn onPress={() => setView('engine')} />
        <Card title={`Instalacja elektryczna — ${typeName(engineType)}`}>
          {w.obwody.map(([n, d], i) => <Entry key={i} title={n} sub={d} />)}
        </Card>
        <Card title="Typowe kolory przewodów">
          {w.kolory.map(([c, f], i) => (
            <View key={i} style={s.tableRow}><Text style={s.tableCell}>{c}</Text><Text style={s.tableCellRight}>{f}</Text></View>
          ))}
        </Card>
        <Text style={s.dim}>Kolory i obwody orientacyjne — zawsze zweryfikuj ze schematem z DTR pojazdu.</Text>
      </ScrollView>
    );
  };

  const renderElectricalHub = () => {
    const sections = Object.entries(ELECTRICAL_DATABASE).filter(([,v]) => v && typeof v === 'object' && !Array.isArray(v));
    return <ScrollView><BackBtn onPress={goHome}/><Card title="Elektryka — baza warsztatowa 50–250 cc"><Text style={s.dim}>Funkcja przewodu jest ważniejsza niż jego kolor. Pinout i wartości zawsze potwierdź dla konkretnego modelu w DTR.</Text>{sections.map(([key,section]) => <Entry key={key} title={section.title || key}><Text style={s.entryBody}>{Object.entries(section).filter(([k])=>k!=='title' && typeof section[k]==='string').map(([k,v])=>`${k}: ${v}`).join('\n')}</Text>{section.chain&&<Text style={s.entryBody}>Łańcuch: {section.chain.join(' → ')}</Text>}{section.tests&&<Text style={s.entryBody}>Testy: {section.tests.join(' • ')}</Text>}{section.faults&&<Text style={s.entryBody}>Typowe przypadki: {section.faults.join(' • ')}</Text>}</Entry>)}</Card></ScrollView>;
  };

  const renderObd = () => {
    const q = obdQuery.trim().toUpperCase();
    const rows = q ? OBD_CODES.filter(([code,name,detail]) => `${code} ${name} ${detail}`.includes(q)) : OBD_CODES;
    return <ScrollView><BackBtn onPress={goHome}/><Card title="OBD — kody P0xxx">
      <Text style={s.dim}>Offline'owy słownik typowych kodów OBD. Obsługa OBD i znaczenie kodu zależą od ECU, producenta i modelu motocykla/skutera.</Text>
      <TextInput style={s.input} placeholder="Szukaj np. P0301, TPS, lambda..." placeholderTextColor="#666" autoCapitalize="characters" value={obdQuery} onChangeText={setObdQuery}/>
      {rows.length ? rows.map(([code,name,detail]) => <Entry key={code} title={code} sub={name}><Text style={s.entryBody}>{detail}</Text></Entry>) : <Text style={s.empty}>Brak kodu pasującego do wyszukiwania.</Text>}
    </Card><Card title="Jak pracować z kodem"><Text style={s.entryBody}>1. Zapisz kod i warunki wystąpienia.\n2. Sprawdź zasilanie, masę, wiązkę i złącza.\n3. Wykonaj test elementu według DTR.\n4. Usuń przyczynę, skasuj kod zgodnie z procedurą i wykonaj jazdę/test kontrolny.\n5. Nie traktuj samego kodu jako dowodu uszkodzenia konkretnej części.</Text></Card></ScrollView>;
  };

  const renderService = () => {
    const d=SERVICE_DATA[serviceType] || SERVICE_DATA['4T'];
    return <ScrollView><BackBtn onPress={goHome}/><Card title="Płyny i interwały serwisowe">
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:8}}>{['2T','4T','CVT'].map(t=><TouchableOpacity key={t} onPress={()=>setServiceType(t)} style={serviceType===t?s.profileChipActive:s.profileChip}><Text style={s.profileChipText}>{t}</Text></TouchableOpacity>)}</ScrollView>
      <Text style={s.h2}>Płyny / materiały</Text>{d.fluids.map(([a,b],i)=><Entry key={i} title={a} sub={b}/>)}
      <Text style={[s.h2,{marginTop:10}]}>Interwały</Text>{d.intervals.map(([a,b],i)=><Entry key={i} title={a} sub={b}/>)}
      <Text style={s.warning}>⚠️ To baza orientacyjna. Dokładną lepkość, normę, pojemność i interwał potwierdź w DTR konkretnego pojazdu.</Text>
    </Card></ScrollView>;
  };

  const renderElectric = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title="Elektryka — checklista"><Btn onPress={() => setView('electricalHub')}>🔌 Otwórz bazę instalacji 50–250 cc</Btn>
        {ELECTRIC_CHECKS.map((t, i) => <Entry key={i} sub={`• ${t}`} />)}
      </Card>
    </ScrollView>
  );

  const renderLog = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title="Czarna Skrzynka">
        <Text style={s.dim}>VIN łączy wpis z kartoteką pojazdu, jeśli taki VIN istnieje.</Text>
        <TextInput style={s.input} placeholder="Numer VIN" placeholderTextColor="#666" value={logVin} onChangeText={setLogVin} />
        <TextInput style={[s.input, s.textarea]} placeholder="Opis wykonanej operacji" placeholderTextColor="#666" value={logDesc} onChangeText={setLogDesc} multiline />
        <Btn onPress={addLog}>+ Zapisz wpis</Btn>
      </Card>
      <Card title={`Historia (${logs.length})`}>
        {logs.length === 0 ? <Text style={s.empty}>Brak wpisów</Text> : logs.slice().reverse().map((l, i) => <Entry key={l.id||i} title={`VIN: ${l.vin || '—'}`} sub={`${l.date}${l.vehicleId?' · przypisany do pojazdu':' · wpis ogólny'}`}><Text style={s.entryBody}>{l.desc}</Text></Entry>)}
      </Card>
    </ScrollView>
  );

  const renderNotes = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title="Notatnik Mechanika">
        <Text style={s.dim}>Podaj VIN pojazdu, aby notatka trafiła do jego historii.</Text>
        <TextInput style={s.input} placeholder="VIN (opcjonalnie)" placeholderTextColor="#666" value={noteVin} onChangeText={setNoteVin} />
        <TextInput style={[s.input, s.textarea]} placeholder="Notatka..." placeholderTextColor="#666" value={noteText} onChangeText={setNoteText} multiline />
        <Btn onPress={addNote}>+ Dodaj notatkę</Btn>
      </Card>
      <Card title={`Zapisane (${notes.length})`}>
        {notes.length === 0 ? <Text style={s.empty}>Brak notatek</Text> : notes.slice().reverse().map((n, i) => <Entry key={n.id||i} title={n.vin || 'Ogólna'} sub={`${n.date}${n.vehicleId?' · przypisana do pojazdu':' · wpis ogólny'}`}><Text style={s.entryBody}>{n.text}</Text></Entry>)}
      </Card>
    </ScrollView>
  );

  const renderShop = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title="Cennik 3-Tier">
        {PARTS_PRICES.map(([name, eco, turbo, prem], i) => (
          <View key={i} style={s.tierRow}>
            <Text style={s.tierName}>{name}</Text>
            <View style={s.tierPrices}>
              <TouchableOpacity onPress={() => addShop(name, 'Economy', eco)}><Text style={s.tierEco}>Eco {eco}zł</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => addShop(name, 'Turbo Diesel', turbo)}><Text style={s.tierTurbo}>TD {turbo}zł</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => addShop(name, 'Premium', prem)}><Text style={s.tierPrem}>Prem {prem}zł</Text></TouchableOpacity>
            </View>
          </View>
        ))}
      </Card>
      <Card title={`Lista zakupowa (${shop.length})`}>
        {shop.length === 0 ? <Text style={s.empty}>Pusta lista</Text> :
          shop.slice().reverse().map((i2, i) => <Entry key={i} sub={`${i2.name} — ${i2.tier} (${i2.price}zł)`} />)}
        {shop.length > 0 && <Btn onPress={clearShop}>Wyczyść listę</Btn>}
      </Card>
    </ScrollView>
  );

  const renderSearch = () => {
    const q = query.trim().toLowerCase();
    const nRes = q ? notes.filter(n => (n.vin || '').toLowerCase().includes(q) || n.text.toLowerCase().includes(q)) : [];
    const lRes = q ? logs.filter(l => (l.vin || '').toLowerCase().includes(q) || l.desc.toLowerCase().includes(q)) : [];
    return (
      <ScrollView>
        <Card title="Szukaj po VIN / słowie kluczowym">
          <TextInput style={s.input} placeholder="Wpisz VIN lub frazę..." placeholderTextColor="#666" value={query} onChangeText={setQuery} />
          {q !== '' && nRes.length === 0 && lRes.length === 0 && <Text style={s.empty}>Brak wyników</Text>}
          {nRes.map((n, i) => <Entry key={'n' + i} title={`Notatka · ${n.vin || '—'}`} sub={n.date}><Text style={s.entryBody}>{n.text}</Text></Entry>)}
          {lRes.map((l, i) => <Entry key={'l' + i} title={`Log · ${l.vin || '—'}`} sub={l.date}><Text style={s.entryBody}>{l.desc}</Text></Entry>)}
        </Card>
      </ScrollView>
    );
  };

  const renderMix = () => {
    const liters = parseFloat(mixLiters.replace(',', '.'));
    const ml = liters > 0 ? Math.round((liters * 1000) / mixRatio) : null;
    return (
      <ScrollView>
        <BackBtn onPress={goHome} />
        <Card title="Kalkulator mieszanki 2T">
          <TextInput style={s.input} placeholder="Ilość paliwa (litry)" placeholderTextColor="#666" keyboardType="decimal-pad" value={mixLiters} onChangeText={setMixLiters} />
          <View style={s.tierPrices}>
            {[25, 32, 40, 50, 100].map(r => (
              <TouchableOpacity key={r} onPress={() => setMixRatio(r)}>
                <Text style={mixRatio === r ? s.tierTurbo : s.tierEco}>1:{r}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={[s.h2, { textAlign: 'center', marginTop: 12 }]}>
            {ml ? `${ml} ml oleju na ${mixLiters} l benzyny` : 'Wpisz ilość paliwa'}
          </Text>
        </Card>
      </ScrollView>
    );
  };

  const renderReminders = () => {
    const today = new Date().toISOString().slice(0, 10);
    return (
      <ScrollView>
        <BackBtn onPress={goHome} />
        <Card title="Nowe przypomnienie">
          <TextInput style={s.input} placeholder="VIN (opcjonalnie)" placeholderTextColor="#666" value={remVin} onChangeText={setRemVin} />
          <TextInput style={s.input} placeholder="Co zrobić (np. wymiana oleju)" placeholderTextColor="#666" value={remDesc} onChangeText={setRemDesc} />
          <TextInput style={s.input} placeholder="Termin (RRRR-MM-DD)" placeholderTextColor="#666" value={remDate} onChangeText={setRemDate} />
          <Btn onPress={addReminder}>+ Dodaj przypomnienie</Btn>
        </Card>
        <Card title={`Harmonogram (${reminders.length})`}>
          {reminders.length === 0 ? <Text style={s.empty}>Brak przypomnień</Text> :
            reminders.slice().sort((a, b) => a.date.localeCompare(b.date)).map((r, i) => {
              const overdue = r.date < today;
              return <Entry key={i} title={r.desc} sub={`${r.vin || '—'} · termin: ${r.date}${overdue ? ' ⚠️ PO TERMINIE' : ''}`} />;
            })}
        </Card>
      </ScrollView>
    );
  };

  const renderChecklistView = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title="Checklista przeglądu okresowego">
        {CHECKLIST_ITEMS.map((t, i) => {
          const isDone = checkDone.includes(i);
          return (
            <TouchableOpacity key={i} onPress={() => toggleCheck(i)} style={s.entry}>
              <Text style={isDone ? s.rewardReady : s.entrySub}>{isDone ? '☑ ' : '☐ '}{t}</Text>
            </TouchableOpacity>
          );
        })}
      </Card>
      <Btn onPress={resetChecklist}>🔁 Wyczyść / nowy przegląd</Btn>
    </ScrollView>
  );

  const renderSubmit = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title="Zgłoś własne rozwiązanie">
        <Text style={s.dim}>Kontekst: {diagCrumbs.join(' › ')}</Text>
        <TextInput style={s.input} placeholder="Twój nick (opcjonalnie)" placeholderTextColor="#666" value={submitName} onChangeText={setSubmitName} />
        <TextInput style={[s.input, s.textarea]} placeholder="Opisz przyczynę/rozwiązanie, które sprawdziło się u Ciebie..." placeholderTextColor="#666" value={submitText} onChangeText={setSubmitText} multiline />
        <Btn onPress={submitSolution}>📤 Wyślij do zatwierdzenia (+5 pkt)</Btn>
        <Text style={s.dimSmall}>Zgłoszenie czeka na akceptację właściciela. Po zatwierdzeniu trafi do wspólnej bazy diagnostycznej.</Text>
      </Card>
    </ScrollView>
  );

  const renderRewards = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title={`Twoje punkty: ${points}`}>
        {REWARDS.map((r, i) => (
          <Entry key={i} title={`${r.pts} pkt`} sub={r.label}>
            <Text style={points >= r.pts ? s.rewardReady : s.rewardLocked}>{points >= r.pts ? '✅ Odblokowana' : `Brakuje ${r.pts - points} pkt`}</Text>
          </Entry>
        ))}
      </Card>
      <Card title={`Twoje zgłoszenia (${submissions.length})`}>
        {submissions.length === 0 ? <Text style={s.empty}>Brak zgłoszeń</Text> :
          submissions.slice().reverse().map((sub, i) => (
            <Entry key={i} title={sub.path} sub={`${sub.status === 'pending' ? '⏳ Oczekuje' : sub.status} · ${sub.date}`}>
              <Text style={s.entryBody}>{sub.text}</Text>
            </Entry>
          ))}
      </Card>
    </ScrollView>
  );

  const renderPro = () => (
    <ScrollView>
      <BackBtn onPress={goHome} />
      <Card title={isPro ? '✅ Masz plan PRO' : 'Przejdź na PRO'}>
        {!isPro && <Text style={[s.h2, { textAlign: 'center', marginBottom: 10 }]}>{PRO_PRICE}</Text>}
        <View style={s.tableRow}><Text style={[s.tableCell, { fontWeight: 'bold' }]}>Funkcja</Text><Text style={[s.tableCell, { fontWeight: 'bold', textAlign: 'right' }]}>FREE / PRO</Text></View>
        {PLAN_FEATURES.map(([label, free, pro], i) => (
          <View key={i} style={s.tableRow}>
            <Text style={s.tableCell}>{label}</Text>
            <Text style={s.tableCellRight}>{typeof free === 'boolean' ? (free ? '✓' : '—') : free} / {typeof pro === 'boolean' ? (pro ? '✓' : '—') : pro}</Text>
          </View>
        ))}
        {!isPro
          ? <Btn onPress={() => Alert.alert('Przejść na PRO?', `${PRO_PRICE} — tryb testowy, bez realnej płatności (na razie).`, [{ text: 'Anuluj' }, { text: 'Aktywuj', onPress: upgradeToPro }])}>⭐ Przejdź na PRO</Btn>
          : <Btn onPress={() => Alert.alert('Wyłączyć PRO?', 'To tylko tryb testowy do sprawdzenia limitów Free.', [{ text: 'Anuluj' }, { text: 'Wyłącz', onPress: downgradeToFree }])}>Wyłącz PRO (test)</Btn>}
        <Text style={s.dimSmall}>Prawdziwe płatności w App Store / Google Play podłączymy po konfiguracji konta dewelopera i RevenueCat.</Text>
      </Card>
    </ScrollView>
  );

  const renderSettings = () => (
    <ScrollView>
      <BackBtn onPress={goHome}/>
      <Card title="Tryb aplikacji">
        <Text style={s.dim}>Ten sam NAPRAWNIK, dwa sposoby pracy. Dane pozostają lokalnie na urządzeniu.</Text>
        <Btn onPress={()=>changeMode('workshop')}>{appMode==='workshop'?'✓ ':''}🛠️ WARSZTAT — klient, pojazd, diagnoza, naprawa</Btn>
        <Btn onPress={()=>changeMode('owner')}>{appMode==='owner'?'✓ ':''}🏍️ AMATOR — własne pojazdy, diagnoza i serwis</Btn>
      </Card>
      <Card title="Kameleon — wygląd">
        <Text style={s.dim}>Aktywny: {themeLabel}</Text>
        <TouchableOpacity style={themeCard} onPress={()=>changeTheme('kameleon')}><LinearGradient colors={['#8a2be2','#d21cff','#ff8a00']} start={{x:0,y:0.5}} end={{x:1,y:0.5}} style={themePreview}><Text style={s.themePreviewText}>🦎 Kameleon · Fiolet → Magenta → Pomarańcz</Text></LinearGradient></TouchableOpacity>
        <TouchableOpacity style={themeCard} onPress={()=>changeTheme('purple')}><LinearGradient colors={['#5b21b6','#8a2be2']} start={{x:0,y:0.5}} end={{x:1,y:0.5}} style={themePreview}><Text style={s.themePreviewText}>Fioletowy</Text></LinearGradient></TouchableOpacity>
        <TouchableOpacity style={themeCard} onPress={()=>changeTheme('orange')}><LinearGradient colors={['#ff4f8b','#ff8a00']} start={{x:0,y:0.5}} end={{x:1,y:0.5}} style={themePreview}><Text style={s.themePreviewText}>Pomarańczowy</Text></LinearGradient></TouchableOpacity>
      </Card>
      <Card title="Dane i konto">
        <Text style={s.dim}>Wersja V2.6.1 Stage 7 · {appMode==='workshop'?'Tryb warsztatowy':'Tryb właściciela'} · {themeLabel}</Text>
        <Text style={s.dim}>Pojazdy: {vehicles.length} · Naprawy: {repairs.length} · Diagnozy: {diagHistory.length}</Text>
        <Btn onPress={() => setView('pro')}>{isPro ? '⭐ Zarządzaj PRO' : '⭐ Zobacz PRO'}</Btn>
        <Btn onPress={exportData}>📤 Eksportuj backup</Btn>
        <Btn onPress={() => Alert.alert('Uwaga', 'Na pewno usunąć wszystkie dane?', [
          { text: 'Anuluj' }, { text: 'Usuń', onPress: async () => {
            await AsyncStorage.multiRemove(['naprawnik_notes','naprawnik_log','naprawnik_shop','naprawnik_submissions','naprawnik_points','naprawnik_reminders','naprawnik_checklist_done','naprawnik_pro','naprawnik_vehicles','naprawnik_repairs','naprawnik_diag_history','naprawnik_health_profiles','naprawnik_photo_cases','naprawnik_mode','naprawnik_theme']);
            setNotes([]); setLogs([]); setShop([]); setSubmissions([]); setPoints(0); setReminders([]); setCheckDone([]); setVehicles([]); setRepairs([]); setDiagHistory([]); setHealthProfiles([]); setPhotoCases([]); setIsPro(false); setAppMode('workshop'); setTheme('kameleon'); setRepairTest({before:'',beforeResult:'',after:'',afterResult:'',passed:'',notes:''});
          }}
        ])}>🗑️ Wyczyść wszystkie dane</Btn>
      </Card>
    </ScrollView>
  );

  const screens = {
    home: renderHome, diag: renderDiag, engine: renderEngine, electric: renderElectric, electricalHub: renderElectricalHub,
    log: renderLog, notes: renderNotes, shop: renderShop, search: renderSearch,
    submit: renderSubmit, rewards: renderRewards, settings: renderSettings,
    mix: renderMix, service: renderService, obd: renderObd, reminders: renderReminders, checklist: renderChecklistView, diagFlow: renderDiagFlow, vehicles: renderVehicles, vehicleDetail: renderVehicleDetail, models: renderModels, engineProfile: renderEngineProfile, multimeter: renderMultimeter,
    torque: renderTorque, wiring: renderWiring, pro: renderPro,
  };
  const bottomNavKey = ['search', 'settings'].includes(view) ? view : 'home';

  return (
    <SafeAreaView style={s.safe}>
      <ExpoStatusBar style="light" />
      <LinearGradient colors={theme==='purple'?['#5b21b6','#8a2be2']:theme==='orange'?['#ff4f8b','#ff8a00']:['#8a2be2','#d21cff','#ff8a00']} start={{x:0,y:0.5}} end={{x:1,y:0.5}} style={s.topbar}>
        <Text style={s.topbarText}>🦎 NAPRAWNIK Kameleon</Text>
        <Text style={s.topbarText}>{isPro ? '⭐ PRO' : 'FREE'}</Text>
      </LinearGradient>
      <View style={s.screen}>{screens[view] ? screens[view]() : renderHome()}</View>
      <View style={s.nav}>
        <TouchableOpacity onPress={goHome}><Text style={bottomNavKey === 'home' ? s.navActive : s.navItem}>🏠 Home</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setView('search')}><Text style={bottomNavKey === 'search' ? s.navActive : s.navItem}>🔍 Szukaj</Text></TouchableOpacity>
        <TouchableOpacity onPress={() => setView('settings')}><Text style={bottomNavKey === 'settings' ? s.navActive : s.navItem}>⚙️ Ustawienia</Text></TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const C = { bg: '#08070d', panel: '#11101a', border: '#3b214c', accent: '#ff4fd8', accent2: '#8a2be2', orange: '#ff8a00', text: '#f2eef5', dim: '#8f8797' };
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  topbar: { flexDirection: 'row', justifyContent: 'space-between', padding: 10, margin: 8, borderRadius: 4 },
  topbarText: { color: '#fff', fontWeight: 'bold', fontSize: 13 },
  screen: { flex: 1, paddingHorizontal: 8 },
  nav: { flexDirection: 'row', justifyContent: 'space-around', borderTopWidth: 1, borderTopColor: C.border, paddingVertical: 10 },
  navItem: { color: '#888', fontSize: 11 },
  navActive: { color: C.accent, fontSize: 11, fontWeight: 'bold' },
  card: { backgroundColor: C.panel, borderWidth: 1, borderColor: C.border, borderRadius: 6, padding: 12, marginBottom: 10 },
  h2: { color: C.accent, fontSize: 13, fontWeight: 'bold', marginBottom: 8, borderBottomWidth: 1, borderBottomColor: C.border, paddingBottom: 6, textTransform: 'uppercase' },
  grid2: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 10 },
  tile: { width: '48%', backgroundColor: C.panel, borderWidth: 1, borderColor: C.accent2, borderRadius: 6, padding: 14, alignItems: 'center', marginBottom: 10 },
  tileIcon: { fontSize: 22, marginBottom: 5 },
  tileLabel: { fontSize: 11, fontWeight: 'bold', color: '#ffb7ef', textTransform: 'uppercase', textAlign: 'center' },
  btn: { marginBottom: 8 },
  btnGradient: { borderRadius: 8, padding: 12, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.14)' },
  btnText: { color: C.text, fontWeight: 'bold', fontSize: 12, textTransform: 'uppercase' },
  backBtn: { color: C.accent, marginBottom: 10, fontWeight: 'bold' },
  crumbs: { color: C.dim, fontSize: 11, marginBottom: 10 },
  entry: { borderBottomWidth: 1, borderBottomColor: C.border, paddingVertical: 8 },
  entryTitle: { color: C.accent, fontWeight: 'bold', fontSize: 12 },
  entrySub: { color: C.text, fontSize: 12 },
  entryBody: { color: C.text, fontSize: 12, marginTop: 3 },
  empty: { color: C.dim, fontSize: 12, textAlign: 'center', paddingVertical: 14 },
  dim: { color: C.dim, fontSize: 11, marginBottom: 8 },
  dimSmall: { color: C.dim, fontSize: 10, marginTop: 6 },
  input: { backgroundColor: '#000', borderWidth: 1, borderColor: C.border, color: C.text, padding: 8, fontSize: 13, borderRadius: 4, marginBottom: 8 },
  textarea: { minHeight: 60, textAlignVertical: 'top' },
  tableRow: { flexDirection: 'row', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: C.border, paddingVertical: 5 },
  tableCell: { color: C.text, fontSize: 12, flex: 1 },
  tableCellRight: { color: C.accent, fontSize: 12, fontWeight: 'bold' },
  tierRow: { borderBottomWidth: 1, borderBottomColor: C.border, paddingVertical: 8 },
  tierName: { color: C.text, fontSize: 12, marginBottom: 6 },
  tierPrices: { flexDirection: 'row', justifyContent: 'space-between' },
  tierEco: { color: '#7fbf7f', borderWidth: 1, borderColor: C.border, padding: 4, borderRadius: 3, fontSize: 11 },
  tierTurbo: { color: C.accent, borderWidth: 1, borderColor: C.border, padding: 4, borderRadius: 3, fontSize: 11 },
  tierPrem: { color: '#ff6b6b', borderWidth: 1, borderColor: C.border, padding: 4, borderRadius: 3, fontSize: 11 },
  rewardReady: { color: '#7fbf7f', fontSize: 11, fontWeight: 'bold', marginTop: 3 },
  result: { color: C.accent, fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  warning: { color: '#ffcc66', fontSize: 12, marginBottom: 10 },
  rewardLocked: { color: C.dim, fontSize: 11, marginTop: 3 },
  hero: { borderRadius: 14, padding: 18, marginBottom: 10, borderWidth: 1, borderColor: C.accent2 },
  heroBrand: { color: '#fff', fontSize: 26, fontWeight: '900', letterSpacing: 1 },
  heroKameleon: { color: '#ff69df', fontSize: 17, fontWeight: '900', letterSpacing: 3 },
  heroSub: { color: '#f2eef5', fontSize: 12, marginTop: 8 },
  heroPowered: { color: '#ff9a3c', fontSize: 10, marginTop: 4 },
  alert: { borderWidth: 2, borderColor: C.accent, borderStyle: 'dashed', borderRadius: 4, padding: 8, alignItems: 'center', marginBottom: 10 },
  alertTitle: { color: C.accent, fontWeight: 'bold', fontSize: 11 },
  alertSub: { color: C.accent, fontSize: 11 },
  heroRow: { flexDirection:'row', alignItems:'center' },
  heroLogo: { width:54, height:54, borderRadius:27, backgroundColor:'rgba(255,255,255,0.07)', borderWidth:1, borderColor:C.accent, alignItems:'center', justifyContent:'center', marginRight:10 },
  heroLogoText: { fontSize:30 },
  modePill: { borderWidth:1, borderColor:C.orange, borderRadius:20, paddingHorizontal:10, paddingVertical:7 },
  modePillText: { color:'#fff', fontSize:9, fontWeight:'900' },
  profileChip: { borderWidth:1, borderColor:C.border, backgroundColor:'#0a0910', borderRadius:18, paddingHorizontal:10, paddingVertical:8, marginRight:6 },
  profileChipActive: { borderWidth:1, borderColor:C.orange, backgroundColor:'#29102b', borderRadius:18, paddingHorizontal:10, paddingVertical:8, marginRight:6 },
  profileChipText: { color:C.text, fontSize:10, fontWeight:'700' },
  themeCard: { marginBottom:8, borderRadius:9, overflow:'hidden' },
  themePreview: { padding:13, borderWidth:1, borderColor:'rgba(255,255,255,0.15)' },
  themePreviewText: { color:'#fff', fontWeight:'800', fontSize:11 },
});
