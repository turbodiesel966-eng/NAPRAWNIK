# NAPRAWNIK V2 KAMELEON — STAGE 7

## Cel
Domknięcie warstwy pojazdu, warsztatu i nowych funkcji ustalonych dla V2 przed budową APK.

## Dodane
- Vehicle Health Profile — stan akumulatora, ładowania, kompresji, temperatury, oleju, OBD, hamulców i opon.
- Diagnostic Vehicle Diary — wspólna oś czasu diagnoz, napraw i dokumentacji zdjęciowej.
- Learning From Cases — wyszukiwanie podobnych przypadków w zapisanych naprawach.
- Sensor Hub — akcelerometr, żyroskop i światło telefonu; wyłącznie jako pomiary pomocnicze, bez udawania miernika RPM/temperatury/napięcia.
- Dokumentacja zdjęciowa — aparat/galeria + opis obserwacji + zapis do historii pojazdu.
- Klient/zlecenie — dane klienta, robocizna, koszt części, marża i status naprawy.
- Raport dla klienta — udostępniany tekstowy raport z kartoteki, stanu i wykonanych prac.
- Backup schema v7.
- Walidator projektu rozszerzony o nowe moduły.
- Expo ImagePicker i Expo Sensors dodane jako zależności zgodne z Expo SDK 54.

## Zasady
- Zdjęcie jest dokumentacją; lokalna wersja nie udaje automatycznej ekspertyzy AI.
- Sensor telefonu nie zastępuje multimetru, manometru, termometru ani interfejsu diagnostycznego.
- Parametry techniczne nadal wymagają weryfikacji z DTR konkretnego pojazdu.

## Walidacja
- `node --check App.js` — OK
- `node --check DiagnosisCore.js` — OK
- `node --check NAPRAWNIK_ELEKTRYKA_BAZA_v1.js` — OK
- `node validate_project.js` — OK

## Ważne
Archiwum jest źródłowym Stage 7. Zależności Expo zostały wpisane do `package.json`, ale instalację pakietów należy wykonać w Codespace przed testem uruchomieniowym/APK (`npm install` lub `npx expo install`).


## Stage 7.1 — stabilizacja
- schema backup: v8
- poprawiono reset formularza naprawy, aby nie gubił robocizny/części/marży/statusu
- raport klienta uwzględnia koszt robocizny i części, gdy brak łącznego kosztu
- po zapisaniu dokumentacji zdjęciowej czyści się bieżący URI
- ujednolicono numerację wersji ekranu i backupu
